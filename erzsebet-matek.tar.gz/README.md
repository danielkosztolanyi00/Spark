# Erzsébet · Matematika korrepetálás

Portfolio project — a warm, playful, and academic one-page site for **Erzsébet**, a freelance
high-school math teacher in Szeged with 30+ years of experience. Built as a static Next.js export.

## Features

- **Hero** with floating math symbols on a graph-paper backdrop
- **Szolgáltatások** — érettségi felkészítés, versenyfelkészítés, általános fejlesztés
- **Rólam** — story + stats, first two lessons free
- **🔍 Találd meg a hibát!** — an interactive "find the deliberate mistake" mini-game with
  several worked problems, instant feedback, and explanations (the signature feature)
- **Vélemények** — student & parent testimonials
- **Kapcsolat** — a friendly questionnaire-style contact form

All contact details (phone, address) are placeholders.

## Tech

- Next.js 16 (App Router, `output: "export"`)
- React 19
- Tailwind CSS v4
- Fraunces (display) + Nunito (body) via Google Fonts

## Development

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # static export → ./out
```

## Deployment

The build produces a static `./out` folder. Serve it with any static host or Nginx, e.g.
on the subdomain `erzsebet-matek.danielkosztolanyi.com`.
