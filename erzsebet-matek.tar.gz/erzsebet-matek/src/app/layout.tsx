import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Erzsébet · Matematika korrepetálás | Érettségi & versenyfelkészítés Szegeden",
  description:
    "30+ év tapasztalat a középiskolai matematikatanításban. Érettségi felkészítés (közép- és emelt szint), versenyfelkészítés és általános fejlesztés egyéni órákon. Az első két óra ingyenes!",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="hu">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Nunito:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
