const stats = [
  { num: "30+", label: "év tanítási tapasztalat" },
  { num: "200+", label: "egyéni diák felkészítve" },
  { num: "90%", label: "emelt szintű érettségin jól teljesített" },
  { num: "2", label: "ingyenes próbaóra" },
];

export default function About() {
  return (
    <section id="rolam" className="py-24 px-6" style={{ background: "var(--paper)" }}>
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-14 items-center">
        {/* Portrait card */}
        <div className="relative">
          <div
            className="aspect-[4/5] rounded-3xl flex items-center justify-center relative overflow-hidden graph-paper"
            style={{ background: "var(--paper-2)", border: "1px solid var(--border)" }}
          >
            <span className="font-display font-bold opacity-30" style={{ fontSize: "9rem", color: "var(--rust)" }}>
              E
            </span>
            <span className="absolute bottom-5 left-5 right-5 text-center text-xs font-semibold" style={{ color: "var(--ink-soft)" }}>
              (Ide kerül Erzsébet fotója)
            </span>
          </div>
          {/* playful sticker */}
          <div
            className="absolute -bottom-5 -right-3 rounded-2xl px-5 py-3 font-display font-bold rotate-6"
            style={{ background: "var(--mustard)", color: "var(--ink)", boxShadow: "0 8px 20px rgba(59,47,42,0.15)" }}
          >
            „A te tempódban."
          </div>
        </div>

        {/* Story */}
        <div>
          <p className="text-sm font-bold tracking-widest uppercase mb-3" style={{ color: "var(--teal)" }}>
            Rólam
          </p>
          <h2 className="font-display font-bold text-4xl leading-tight mb-6" style={{ color: "var(--ink)" }}>
            Erzsébet vagyok — és imádom, amikor leesik a tantusz
          </h2>
          <div className="flex flex-col gap-4 text-base leading-relaxed" style={{ color: "var(--ink-soft)" }}>
            <p>
              Több mint <b style={{ color: "var(--ink)" }}>három évtizedet</b> töltöttem középiskolai
              matematikatanárként. Ez idő alatt diákok százaival dolgoztam — a bukás szélén állóktól
              egészen az országos versenyekre készülőkig.
            </p>
            <p>
              Az évek alatt megtanultam, hogy nincs „matekos fej" és „nem matekos fej" — csak
              <b style={{ color: "var(--ink)" }}> jó és rossz magyarázat</b> létezik. Az egyéni
              órákon mindig megkeresem azt a szálat, amin keresztül neked is összeáll a kép.
            </p>
            <p>
              Számos tanítványom ért el kiváló eredményt érettségin és felvételin — de amire a
              legbüszkébb vagyok, az a pillanat, amikor egy diák először mondja ki: „<i>áá, hát ez
              ennyire egyszerű?</i>"
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-9">
            {stats.map((s) => (
              <div
                key={s.label}
                className="rounded-2xl p-5"
                style={{ background: "var(--card)", border: "1px solid var(--border)" }}
              >
                <div className="font-display font-bold text-3xl mb-1" style={{ color: "var(--rust)" }}>
                  {s.num}
                </div>
                <div className="text-xs font-semibold leading-snug" style={{ color: "var(--ink-soft)" }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
