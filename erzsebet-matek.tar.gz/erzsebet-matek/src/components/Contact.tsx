"use client";

const infos = [
  { icon: "📞", label: "Telefon", value: "+36 20 000 0000", href: "tel:+36200000000" },
  { icon: "✉️", label: "E-mail", value: "erzsi@matekoraszeged.hu", href: "mailto:erzsi@matekoraszeged.hu" },
  { icon: "📍", label: "Hol", value: "Szeged, Unikornis utca 987/B", href: null },
  { icon: "💻", label: "Online is", value: "Az egész országból", href: null },
];

const goals = ["Érettségi – közép", "Érettségi – emelt", "Verseny", "Felzárkózás", "Még nem tudom"];

const inputStyle = {
  border: "none",
  borderBottom: "2px dashed var(--border)",
  background: "transparent",
  color: "var(--ink)",
  borderRadius: 0,
};

export default function Contact() {
  return (
    <section id="kapcsolat" className="py-24 px-6" style={{ background: "var(--paper-2)" }}>
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <p className="handw text-2xl -rotate-1" style={{ color: "var(--pen-red)" }}>
            Vágjuk bele!
          </p>
          <h2 className="handw font-bold text-5xl" style={{ color: "var(--ink)" }}>
            Foglald le a két ingyenes órát ✂️
          </h2>
        </div>

        <div className="grid md:grid-cols-[1fr_1.3fr] gap-8 items-stretch">
          {/* Left — info on a sticky */}
          <div className="flex">
            <div
              className="sticky rounded-sm p-7 w-full rotate-[-1.5deg]"
              style={{ background: "var(--highlight-soft)" }}
            >
              <p className="handw text-3xl mb-5" style={{ color: "var(--ink)" }}>
                Így érsz el:
              </p>
              <div className="flex flex-col gap-5">
                {infos.map((item) => (
                  <div key={item.label} className="flex gap-3 items-start">
                    <span className="text-xl">{item.icon}</span>
                    <div>
                      <div className="text-xs font-bold" style={{ color: "var(--ink-soft)" }}>
                        {item.label}
                      </div>
                      {item.href ? (
                        <a href={item.href} className="handw text-2xl no-underline hover:underline" style={{ color: "var(--pen-blue)" }}>
                          {item.value}
                        </a>
                      ) : (
                        <span className="handw text-2xl" style={{ color: "var(--ink)" }}>
                          {item.value}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs leading-relaxed mt-6" style={{ color: "var(--ink-soft)" }}>
                24 órán belül válaszolok. Az első óra mindig ingyenes és kötelezettségmentes. 🙂
              </p>
            </div>
          </div>

          {/* Right — worksheet form */}
          <form
            className="rounded-lg p-8 squared relative paper-shadow"
            style={{ background: "var(--card)" }}
            onSubmit={(e) => e.preventDefault()}
          >
            <p className="handw text-3xl mb-1" style={{ color: "var(--pen-red)" }}>
              Jelentkezési lap
            </p>
            <p className="text-xs mb-6" style={{ color: "var(--ink-soft)" }}>
              Tölts ki pár sort, a többit megbeszéljük élőben!
            </p>

            <div className="grid sm:grid-cols-2 gap-5 mb-5">
              <label className="flex flex-col gap-1">
                <span className="handw text-xl" style={{ color: "var(--pen-blue)" }}>A neved:</span>
                <input type="text" placeholder="pl. Nagy Anna" className="px-1 py-2 text-base outline-none" style={inputStyle} />
              </label>
              <label className="flex flex-col gap-1">
                <span className="handw text-xl" style={{ color: "var(--pen-blue)" }}>Telefon / e-mail:</span>
                <input type="text" placeholder="ahol elérlek" className="px-1 py-2 text-base outline-none" style={inputStyle} />
              </label>
            </div>

            <label className="flex flex-col gap-1 mb-5">
              <span className="handw text-xl" style={{ color: "var(--pen-blue)" }}>Ki tanul és melyik évfolyamon?</span>
              <input type="text" placeholder="pl. a lányom, 11. osztály" className="px-1 py-2 text-base outline-none" style={inputStyle} />
            </label>

            <div className="mb-6">
              <span className="handw text-xl block mb-2" style={{ color: "var(--pen-blue)" }}>Mi a cél? (karikázd be 😊)</span>
              <div className="flex flex-wrap gap-2">
                {goals.map((g) => (
                  <label
                    key={g}
                    className="handw text-xl px-4 py-1 rounded-full cursor-pointer transition-all select-none"
                    style={{ border: "2px solid var(--border)", color: "var(--ink)" }}
                  >
                    <input type="radio" name="cel" className="hidden" />
                    {g}
                  </label>
                ))}
              </div>
            </div>

            <label className="flex flex-col gap-1 mb-7">
              <span className="handw text-xl" style={{ color: "var(--pen-blue)" }}>Hol tartasz most? (opcionális)</span>
              <textarea
                rows={3}
                placeholder="pl. a függvények mennek, de a geometriánál elakadok…"
                className="px-1 py-2 text-base outline-none resize-none"
                style={inputStyle}
              />
            </label>

            <button
              type="submit"
              className="handw text-3xl font-bold w-full py-3 rounded-2xl transition-transform hover:scale-[1.02] rotate-[-0.5deg]"
              style={{ background: "var(--pen-red)", color: "var(--chalk)", boxShadow: "0 8px 20px rgba(207,82,64,0.3)" }}
            >
              Elküldöm! →
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
