"use client";

const infos = [
  { icon: "📞", label: "Telefon", value: "+36 20 000 0000", href: "tel:+36200000000" },
  { icon: "📧", label: "E-mail", value: "erzsebet@matekoraszeged.hu", href: "mailto:erzsebet@matekoraszeged.hu" },
  { icon: "📍", label: "Helyszín", value: "Szeged, Unikornis utca 987/B", href: null },
  { icon: "💻", label: "Online is", value: "Online órák az egész országból", href: null },
];

const goals = [
  "Érettségi — középszint",
  "Érettségi — emelt szint",
  "Versenyfelkészítés",
  "Általános fejlesztés / felzárkózás",
  "Még nem tudom pontosan",
];

const inputStyle = { border: "1.5px solid var(--border)", color: "var(--ink)", background: "var(--paper)" };

export default function Contact() {
  return (
    <section id="kapcsolat" className="py-24 px-6 graph-paper" style={{ background: "var(--paper)" }}>
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-14 items-start">
        {/* Left — info */}
        <div>
          <p className="text-sm font-bold tracking-widest uppercase mb-3" style={{ color: "var(--teal)" }}>
            Kapcsolat
          </p>
          <h2 className="font-display font-bold text-4xl leading-tight mb-5" style={{ color: "var(--ink)" }}>
            Foglald le az első{" "}
            <span style={{ color: "var(--rust)" }}>két ingyenes órát</span>
          </h2>
          <p className="text-base leading-relaxed mb-9" style={{ color: "var(--ink-soft)" }}>
            Írd meg pár sorban, hol tartasz és mi a célod — 24 órán belül válaszolok, és
            megbeszéljük az első, kötelezettségmentes időpontot. Az első órára már hozok is
            néhány, hozzád szabott feladatot.
          </p>

          <div className="flex flex-col gap-5">
            {infos.map((item) => (
              <div key={item.label} className="flex gap-4 items-start">
                <span
                  className="w-11 h-11 rounded-xl flex items-center justify-center text-lg shrink-0"
                  style={{ background: "var(--rust-soft)" }}
                >
                  {item.icon}
                </span>
                <div>
                  <div className="text-xs font-bold mb-0.5" style={{ color: "var(--ink-soft)" }}>
                    {item.label}
                  </div>
                  {item.href ? (
                    <a href={item.href} className="font-bold no-underline hover:underline" style={{ color: "var(--rust)" }}>
                      {item.value}
                    </a>
                  ) : (
                    <span className="font-semibold" style={{ color: "var(--ink)" }}>
                      {item.value}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right — questionnaire */}
        <form
          className="rounded-3xl p-8 flex flex-col gap-5"
          style={{ background: "var(--card)", border: "1px solid var(--border)", boxShadow: "0 10px 40px rgba(59,47,42,0.08)" }}
          onSubmit={(e) => e.preventDefault()}
        >
          <h3 className="font-display font-bold text-2xl" style={{ color: "var(--ink)" }}>
            Néhány gyors kérdés 📝
          </h3>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-bold" style={{ color: "var(--ink)" }}>
                Neved
              </label>
              <input
                type="text"
                placeholder="pl. Nagy Anna"
                className="px-4 py-3 rounded-xl text-sm outline-none transition-all"
                style={inputStyle}
                onFocus={(e) => (e.currentTarget.style.borderColor = "var(--rust)")}
                onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-bold" style={{ color: "var(--ink)" }}>
                Telefon vagy e-mail
              </label>
              <input
                type="text"
                placeholder="ahol elérlek"
                className="px-4 py-3 rounded-xl text-sm outline-none transition-all"
                style={inputStyle}
                onFocus={(e) => (e.currentTarget.style.borderColor = "var(--rust)")}
                onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-bold" style={{ color: "var(--ink)" }}>
              Ki fog tanulni, és melyik évfolyamon?
            </label>
            <input
              type="text"
              placeholder="pl. a lányom, 11. osztály"
              className="px-4 py-3 rounded-xl text-sm outline-none transition-all"
              style={inputStyle}
              onFocus={(e) => (e.currentTarget.style.borderColor = "var(--rust)")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-sm font-bold" style={{ color: "var(--ink)" }}>
              Mi a cél?
            </label>
            <div className="flex flex-wrap gap-2">
              {goals.map((g) => (
                <label
                  key={g}
                  className="text-xs font-semibold px-3 py-2 rounded-full cursor-pointer transition-all select-none"
                  style={{ border: "1.5px solid var(--border)", color: "var(--ink-soft)" }}
                >
                  <input type="radio" name="cel" className="hidden peer" />
                  <span className="peer-checked:font-bold">{g}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-bold" style={{ color: "var(--ink)" }}>
              Hol tartasz most? (opcionális)
            </label>
            <textarea
              rows={3}
              placeholder="pl. a függvények mennek, de a geometriánál elakadok…"
              className="px-4 py-3 rounded-xl text-sm outline-none transition-all resize-none"
              style={inputStyle}
              onFocus={(e) => (e.currentTarget.style.borderColor = "var(--rust)")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 rounded-full font-bold text-base transition-transform hover:scale-[1.02]"
            style={{ background: "var(--rust)", color: "#fff", boxShadow: "0 8px 24px rgba(210,96,58,0.3)" }}
          >
            Foglalom az ingyenes órát →
          </button>

          <p className="text-xs text-center" style={{ color: "var(--ink-soft)" }}>
            24 órán belül válaszolok. Az első két óra ingyenes és kötelezettségmentes.
          </p>
        </form>
      </div>
    </section>
  );
}
