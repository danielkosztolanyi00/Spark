"use client";
import { useState } from "react";

// Every answer manually verified:
// Q1: 4x−7=13 → 4x=20 → x=5 ✓
// Q2: √(25+144)=√169=13 ✓ (NOT 5+12)
// Q3: (a−b)² = a²−2ab+b² ✓
// Q4: log₂(32)=5 because 2⁵=32 ✓
// Q5: x²+4=0 → no real solution (x²≥0) ✓
const problems = [
  {
    question: "Melyik az egyenlet helyes megoldása?",
    formula: "4x − 7 = 13",
    options: ["x = 5", "x = 20", "x = 6", "x = 1,5"],
    correct: 0,
    explanation: "4x = 13 + 7 = 20, tehát x = 20 ÷ 4 = 5. Ellenőrzés: 4·5 − 7 = 13 ✓",
    trap: "Gyakori hiba: elfelejtenek elosztani 4-gyel, és x = 20-at írnak.",
  },
  {
    question: "Mennyi az értéke?",
    formula: "√(25 + 144)",
    options: ["13", "17", "7", "12"],
    correct: 0,
    explanation: "Először a gyök alatt adunk össze: 25 + 144 = 169, és √169 = 13.",
    trap: "Sokan √25 + √144 = 5 + 12 = 17-et írnak — de √(a+b) ≠ √a + √b!",
  },
  {
    question: "Melyik a helyes kifejtés?",
    formula: "(a − b)²",
    options: ["a² − 2ab + b²", "a² − b²", "a² + 2ab + b²", "a² − 2ab − b²"],
    correct: 0,
    explanation: "(a−b)(a−b) = a² − 2ab + b². Az utolsó tag pozitív, mert (−b)·(−b) = +b².",
    trap: "Tipikus csapda: mínuszt írni a b² elé — pedig (−b)² mindig pozitív.",
  },
  {
    question: "Mi az értéke?",
    formula: "log₂ 32",
    options: ["5", "4", "16", "6"],
    correct: 0,
    explanation: "Azt keressük, amire 2-t emelve 32-t kapunk: 2⁵ = 32. Tehát log₂ 32 = 5.",
    trap: "Könnyű elvéteni a szomszédos hatványokkal: 2⁴ = 16, 2⁶ = 64.",
  },
  {
    question: "Hány valós megoldása van?",
    formula: "x² + 4 = 0",
    options: ["Nincs valós megoldása", "Kettő", "Egy", "x = ±2"],
    correct: 0,
    explanation: "x² = −4 lenne, de négyzet sosem negatív (x² ≥ 0). Nincs valós megoldás.",
    trap: "Az x = ±2 csábító, de 2² = 4, nem −4.",
  },
];

export default function FindTheMistake() {
  const [pIndex, setPIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState<Set<number>>(new Set());

  const problem = problems[pIndex];
  const isAnswered = picked !== null;
  const isCorrect = picked === problem.correct;
  const allDone = score === problems.length;

  const handlePick = (i: number) => {
    if (isAnswered) return;
    setPicked(i);
    if (i === problem.correct && !answered.has(pIndex)) {
      setScore((s) => s + 1);
      setAnswered((prev) => new Set(prev).add(pIndex));
    }
  };

  const next = () => {
    setPIndex((i) => (i + 1) % problems.length);
    setPicked(null);
  };

  return (
    <section id="talald-meg" className="py-24 px-6 relative" style={{ background: "var(--paper-2)" }}>
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <p className="handw text-2xl -rotate-1" style={{ color: "var(--pen-red)" }}>
            Játssz egy kicsit!
          </p>
          <h2 className="handw font-bold text-5xl mb-3" style={{ color: "var(--ink)" }}>
            🎯 Melyik a helyes megoldás?
          </h2>
          <p className="text-base leading-relaxed max-w-xl mx-auto" style={{ color: "var(--ink-soft)" }}>
            Öt feladat, négy-négy válasszal. Ugyanezeket a klasszikus csapdákat kerüljük el együtt
            az órákon is — próbáld ki!
          </p>
        </div>

        {/* chalkboard */}
        <div
          className="rounded-2xl p-6 sm:p-9 relative"
          style={{
            background: "linear-gradient(160deg, var(--chalkboard) 0%, var(--chalkboard-2) 100%)",
            border: "10px solid #8a6a44",
            boxShadow: "0 20px 50px rgba(0,0,0,0.3), inset 0 0 80px rgba(0,0,0,0.25)",
          }}
        >
          {/* score chalk + progress */}
          <div className="flex items-center justify-between mb-5">
            <span className="handw text-2xl" style={{ color: "var(--chalk)" }}>
              Pont: {score} / {problems.length}
            </span>
            <div className="flex gap-1.5">
              {problems.map((_, i) => (
                <div
                  key={i}
                  className="w-2.5 h-2.5 rounded-full"
                  style={{
                    background: i === pIndex ? "#ffe39a" : answered.has(i) ? "#9fd4bf" : "rgba(244,239,225,0.25)",
                  }}
                />
              ))}
            </div>
          </div>

          <p className="text-sm font-bold mb-1" style={{ color: "rgba(244,239,225,0.6)" }}>
            {pIndex + 1}. feladat — {problem.question}
          </p>
          <p className="handw mb-7" style={{ color: "var(--chalk)", fontSize: "clamp(2.5rem, 7vw, 3.5rem)" }}>
            {problem.formula}
          </p>

          <div className="grid sm:grid-cols-2 gap-3">
            {problem.options.map((opt, i) => {
              const thisCorrect = i === problem.correct;
              const thisPicked = i === picked;
              let border = "rgba(244,239,225,0.3)";
              let bg = "rgba(244,239,225,0.04)";
              let color = "var(--chalk)";
              if (isAnswered) {
                if (thisCorrect) {
                  border = "#9fd4bf";
                  bg = "rgba(159,212,191,0.16)";
                  color = "#bfe9d8";
                } else if (thisPicked) {
                  border = "#f0a896";
                  bg = "rgba(240,168,150,0.14)";
                  color = "#f3c3b6";
                }
              }
              return (
                <button
                  key={i}
                  onClick={() => handlePick(i)}
                  disabled={isAnswered}
                  className="text-left rounded-xl px-5 py-3.5 transition-all flex items-center justify-between gap-3 disabled:cursor-default"
                  style={{ background: bg, border: `2px solid ${border}`, color }}
                >
                  <span className="handw text-2xl">
                    <span className="opacity-50 mr-2 text-lg">{String.fromCharCode(97 + i)})</span>
                    {opt}
                  </span>
                  {isAnswered && thisCorrect && <span className="text-xl">✓</span>}
                  {isAnswered && thisPicked && !thisCorrect && <span className="text-xl">✗</span>}
                </button>
              );
            })}
          </div>

          {isAnswered && (
            <div
              className="mt-6 rounded-xl px-5 py-4 animate-pop"
              style={{
                background: isCorrect ? "rgba(159,212,191,0.12)" : "rgba(240,168,150,0.1)",
                border: `1.5px dashed ${isCorrect ? "rgba(159,212,191,0.5)" : "rgba(240,168,150,0.45)"}`,
              }}
            >
              <p className="handw text-3xl mb-1" style={{ color: isCorrect ? "#bfe9d8" : "#f3c3b6" }}>
                {isCorrect ? "Helyes! 🎉" : "Nem egészen…"}
              </p>
              <p className="text-sm leading-relaxed" style={{ color: "rgba(244,239,225,0.85)" }}>
                {problem.explanation}
              </p>
              {!isCorrect && (
                <p className="text-xs leading-relaxed mt-2" style={{ color: "rgba(244,239,225,0.55)" }}>
                  💡 {problem.trap}
                </p>
              )}
            </div>
          )}

          <div className="mt-7 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
            <button
              onClick={next}
              className="handw text-2xl font-bold px-7 py-2 rounded-xl transition-transform hover:scale-105 -rotate-1"
              style={{ background: "#ffe39a", color: "var(--ink)" }}
            >
              {pIndex < problems.length - 1 ? "Következő →" : "Újra elölről →"}
            </button>
            {allDone && (
              <a
                href="#kapcsolat"
                className="handw text-2xl no-underline text-center sm:text-right transition-opacity hover:opacity-80"
                style={{ color: "#bfe9d8" }}
              >
                Mind megvan! 👏 Foglalj ingyenes órát →
              </a>
            )}
          </div>
        </div>

        <p className="text-center text-xs mt-6" style={{ color: "var(--ink-soft)" }}>
          Tipp: az első érzés sokszor jó — de érdemes kétszer is végiggondolni. 🤓
        </p>
      </div>
    </section>
  );
}
