"use client";
import { useState } from "react";

type Problem = {
  task: string;
  steps: string[];
  mistakeStep: number;
  explanation: string;
  correct: string;
};

const problems: Problem[] = [
  {
    task: "Oldd meg az egyenletet:  3·(x − 2) = 2x + 4",
    steps: ["3x − 6 = 2x + 4", "3x − 2x = 4 − 6", "x = −2"],
    mistakeStep: 1,
    explanation:
      "A −6-ot a jobb oldalra átvíve az előjele megváltozik: +6 lesz belőle. Tehát a helyes lépés: 3x − 2x = 4 + 6.",
    correct: "x = 10",
  },
  {
    task: "Egyszerűsítsd a kifejezést:  2 − (3x − 5)",
    steps: ["2 − 3x − 5", "−3x − 3"],
    mistakeStep: 0,
    explanation:
      "A zárójel előtti mínusz MINDEN tag előjelét megfordítja a zárójelen belül — így a −5-ből +5 lesz: 2 − 3x + 5.",
    correct: "−3x + 7",
  },
  {
    task: "Emeld négyzetre:  (x + 3)²",
    steps: ["x² + 3²", "x² + 9"],
    mistakeStep: 0,
    explanation:
      "Az (a + b)² = a² + 2ab + b² azonosság szerint nem hagyhatjuk ki a kétszeres szorzatot: x² + 2·x·3 + 9.",
    correct: "x² + 6x + 9",
  },
];

export default function FindTheMistake() {
  const [pIndex, setPIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [solved, setSolved] = useState(0);
  const [streakProblems, setStreakProblems] = useState<Set<number>>(new Set());

  const problem = problems[pIndex];
  const isCorrect = picked === problem.mistakeStep;
  const isWrong = picked !== null && picked !== problem.mistakeStep;

  const handlePick = (i: number) => {
    if (isCorrect) return; // already solved this one
    setPicked(i);
    if (i === problem.mistakeStep && !streakProblems.has(pIndex)) {
      setSolved((s) => s + 1);
      setStreakProblems((prev) => new Set(prev).add(pIndex));
    }
  };

  const nextProblem = () => {
    setPIndex((i) => (i + 1) % problems.length);
    setPicked(null);
  };

  return (
    <section id="talald-meg" className="py-24 px-6 relative overflow-hidden" style={{ background: "var(--ink)" }}>
      {/* chalkboard feel */}
      <div className="absolute inset-0 opacity-[0.06] graph-paper" style={{ filter: "invert(1)" }} />

      <div className="max-w-3xl mx-auto relative">
        <div className="text-center mb-10">
          <p className="text-sm font-bold tracking-widest uppercase mb-3" style={{ color: "var(--mustard)" }}>
            Interaktív · próbáld ki
          </p>
          <h2 className="font-display font-bold text-4xl mb-4" style={{ color: "var(--paper)" }}>
            🔍 Találd meg a hibát!
          </h2>
          <p className="text-base leading-relaxed max-w-xl mx-auto" style={{ color: "rgba(251,246,238,0.65)" }}>
            Minden megoldásba becsúszott egy klasszikus hiba. Kattints arra a lépésre, ahol
            szerinted elcsúszott a számolás — pont így dolgozunk együtt az órákon is.
          </p>
        </div>

        {/* counter */}
        <div className="flex justify-center mb-6">
          <span
            className="text-sm font-bold px-4 py-1.5 rounded-full"
            style={{ background: "rgba(224,167,63,0.15)", color: "var(--mustard)", border: "1px solid rgba(224,167,63,0.3)" }}
          >
            Megtalált hibák: {solved} / {problems.length}
          </span>
        </div>

        {/* "chalkboard" card */}
        <div
          className="rounded-3xl p-7 sm:p-9"
          style={{ background: "#2b2320", border: "1px solid rgba(251,246,238,0.1)", boxShadow: "0 20px 50px rgba(0,0,0,0.3)" }}
        >
          <p className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: "var(--mustard)" }}>
            Feladat
          </p>
          <p className="font-display text-xl sm:text-2xl mb-7" style={{ color: "var(--paper)" }}>
            {problem.task}
          </p>

          <p className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: "rgba(251,246,238,0.4)" }}>
            Megoldás — hol a hiba?
          </p>
          <div className="flex flex-col gap-3">
            {problem.steps.map((step, i) => {
              const thisCorrect = isCorrect && i === problem.mistakeStep;
              const thisWrongPick = isWrong && i === picked;
              let border = "rgba(251,246,238,0.14)";
              let bg = "rgba(251,246,238,0.04)";
              if (thisCorrect) {
                border = "var(--teal)";
                bg = "rgba(47,125,107,0.18)";
              } else if (thisWrongPick) {
                border = "var(--rust)";
                bg = "rgba(210,96,58,0.15)";
              }
              return (
                <button
                  key={i}
                  onClick={() => handlePick(i)}
                  disabled={isCorrect}
                  className="text-left rounded-xl px-5 py-4 font-display text-lg transition-all flex items-center justify-between gap-3 disabled:cursor-default"
                  style={{ background: bg, border: `1.5px solid ${border}`, color: "var(--paper)" }}
                >
                  <span>
                    <span className="opacity-40 mr-3 text-sm">{i + 1}.</span>
                    {step}
                  </span>
                  {thisCorrect && <span className="text-xl">✓</span>}
                  {thisWrongPick && <span className="text-xl">↩</span>}
                </button>
              );
            })}
          </div>

          {/* feedback */}
          {isWrong && (
            <div
              className="mt-6 rounded-xl px-5 py-4 text-sm font-semibold animate-pop"
              style={{ background: "rgba(210,96,58,0.12)", color: "#f3b9a6", border: "1px solid rgba(210,96,58,0.3)" }}
            >
              Hmm, ez a lépés még helyes 🤔 Nézd meg újra — hol változik meg valami, aminek nem
              kellene? Próbáld újra!
            </div>
          )}

          {isCorrect && (
            <div
              className="mt-6 rounded-xl px-5 py-5 animate-pop"
              style={{ background: "rgba(47,125,107,0.15)", border: "1px solid rgba(47,125,107,0.4)" }}
            >
              <p className="font-display font-bold text-lg mb-2" style={{ color: "#7fd4c0" }}>
                🎉 Pontosan! Itt csúszott el.
              </p>
              <p className="text-sm leading-relaxed mb-3" style={{ color: "rgba(251,246,238,0.8)" }}>
                {problem.explanation}
              </p>
              <p className="text-sm font-bold" style={{ color: "var(--paper)" }}>
                Helyes végeredmény:{" "}
                <span className="font-display" style={{ color: "var(--mustard)" }}>
                  {problem.correct}
                </span>
              </p>
            </div>
          )}

          <div className="mt-7 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
            <button
              onClick={nextProblem}
              className="font-bold px-6 py-3 rounded-full text-sm transition-transform hover:scale-105"
              style={{ background: "var(--mustard)", color: "var(--ink)" }}
            >
              Másik feladat →
            </button>
            {solved === problems.length && (
              <a
                href="#kapcsolat"
                className="text-sm font-bold no-underline text-center sm:text-right transition-opacity hover:opacity-80"
                style={{ color: "#7fd4c0" }}
              >
                Mindet megtaláltad! 👏 Foglalj egy ingyenes órát →
              </a>
            )}
          </div>
        </div>

        <p className="text-center text-xs mt-6" style={{ color: "rgba(251,246,238,0.4)" }}>
          Tipp: a leggyakoribb hibák az előjelekkel és a zárójelek felbontásával történnek.
        </p>
      </div>
    </section>
  );
}
