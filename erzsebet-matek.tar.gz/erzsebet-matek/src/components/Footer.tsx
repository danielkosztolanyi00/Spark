export default function Footer() {
  return (
    <footer className="py-12 px-6" style={{ background: "var(--paper)", borderTop: "2px dashed var(--border)" }}>
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
        <div className="flex items-center gap-3">
          <span
            className="w-11 h-11 rounded-2xl flex items-center justify-center text-2xl handw font-bold -rotate-6"
            style={{ background: "var(--pen-blue)", color: "var(--chalk)" }}
          >
            ƒ
          </span>
          <div>
            <div className="handw font-bold text-2xl" style={{ color: "var(--ink)" }}>
              Erzsi néni matekórái
            </div>
            <div className="text-xs font-bold" style={{ color: "var(--ink-soft)" }}>
              Egyéni órák Szegeden és online
            </div>
          </div>
        </div>

        <div className="flex gap-6 handw text-2xl" style={{ color: "var(--pen-blue)" }}>
          <a href="#rolam" className="no-underline hover:opacity-70" style={{ color: "inherit" }}>Rólam</a>
          <a href="#szolgaltatasok" className="no-underline hover:opacity-70" style={{ color: "inherit" }}>Miben segítek</a>
          <a href="#kapcsolat" className="no-underline hover:opacity-70" style={{ color: "inherit" }}>Kapcsolat</a>
        </div>

        <div className="text-xs" style={{ color: "var(--ink-soft)" }}>
          © {new Date().getFullYear()} Erzsi néni matekórái
          <br />
          Szeged, Unikornis utca 987/B
        </div>
      </div>
    </footer>
  );
}
