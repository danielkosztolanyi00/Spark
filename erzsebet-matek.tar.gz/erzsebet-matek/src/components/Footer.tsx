export default function Footer() {
  return (
    <footer className="py-10 px-6" style={{ background: "var(--ink)" }}>
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <span
            className="w-10 h-10 rounded-xl flex items-center justify-center font-display font-bold text-lg"
            style={{ background: "var(--rust)", color: "#fff" }}
          >
            √
          </span>
          <div>
            <div className="font-display font-bold" style={{ color: "var(--paper)" }}>
              Erzsébet · Matematika
            </div>
            <div className="text-xs" style={{ color: "rgba(251,246,238,0.45)" }}>
              Egyéni órák Szegeden és online
            </div>
          </div>
        </div>

        <div className="flex gap-6 text-sm font-semibold" style={{ color: "rgba(251,246,238,0.5)" }}>
          <a href="#rolam" className="no-underline hover:opacity-80" style={{ color: "inherit" }}>
            Rólam
          </a>
          <a href="#szolgaltatasok" className="no-underline hover:opacity-80" style={{ color: "inherit" }}>
            Szolgáltatások
          </a>
          <a href="#kapcsolat" className="no-underline hover:opacity-80" style={{ color: "inherit" }}>
            Kapcsolat
          </a>
        </div>

        <div className="text-xs text-center md:text-right" style={{ color: "rgba(251,246,238,0.35)" }}>
          © {new Date().getFullYear()} Erzsébet matematika korrepetálás
          <br />
          Szeged, Unikornis utca 987/B
        </div>
      </div>
    </footer>
  );
}
