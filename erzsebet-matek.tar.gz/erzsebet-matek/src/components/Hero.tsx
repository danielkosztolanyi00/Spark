"use client";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center squared overflow-hidden" style={{ background: "var(--paper)" }}>
      {/* red margin line (like a real notebook) */}
      <div className="absolute top-0 bottom-0 left-12 sm:left-20 w-px hidden sm:block" style={{ background: "rgba(207,82,64,0.45)" }} />

      {/* warm glows */}
      <div
        className="absolute -top-24 right-0 w-[440px] h-[440px] rounded-full blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(255,209,82,0.35) 0%, transparent 70%)" }}
      />
      <div
        className="absolute bottom-0 left-1/4 w-[380px] h-[380px] rounded-full blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(47,93,138,0.12) 0%, transparent 70%)" }}
      />

      <div className="max-w-6xl mx-auto px-6 sm:pl-28 py-32 relative w-full grid lg:grid-cols-[1.3fr_1fr] gap-12 items-center">
        {/* Left — greeting + headline */}
        <div>
          <p className="handw text-3xl mb-2 -rotate-2" style={{ color: "var(--pen-blue)" }}>
            Szia! 👋 Erzsi néni vagyok
          </p>

          <h1 className="handw font-bold mb-6" style={{ color: "var(--ink)", fontSize: "clamp(3rem, 7vw, 5.5rem)" }}>
            A matek menni fog —{" "}
            <span className="marker" style={{ color: "var(--ink)" }}>
              együtt biztosan.
            </span>
          </h1>

          <p className="text-lg leading-relaxed mb-9 max-w-xl" style={{ color: "var(--ink-soft)" }}>
            Egyéni matematikaórák Szegeden és online. Türelmesen, lépésről lépésre építjük fel a
            tudást — <b style={{ color: "var(--ink)" }}>érettségire</b>,{" "}
            <b style={{ color: "var(--ink)" }}>versenyre</b>, vagy csak hogy újra magabiztos legyél.
            A te tempódban, a te fejeddel.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#kapcsolat"
              className="handw text-2xl font-bold px-8 py-3 rounded-2xl text-center no-underline transition-transform hover:scale-105 -rotate-1"
              style={{ background: "var(--pen-red)", color: "var(--chalk)", boxShadow: "0 8px 20px rgba(207,82,64,0.3)" }}
            >
              Kérek egy ingyenes órát →
            </a>
            <a
              href="#talald-meg"
              className="handw text-2xl font-bold px-8 py-3 rounded-2xl text-center no-underline transition-all rotate-1"
              style={{ background: "transparent", color: "var(--ink)", border: "2.5px solid var(--ink)" }}
            >
              Játssz egy kvízt! ✏️
            </a>
          </div>

          <div className="mt-10 flex flex-wrap gap-x-7 gap-y-3 text-sm font-bold" style={{ color: "var(--ink-soft)" }}>
            <span>✅ Az első <b style={{ color: "var(--pen-red)" }}>2 óra ingyen</b></span>
            <span>📐 Rád szabott feladatok</span>
            <span>🎓 30+ év a katedrán</span>
          </div>
        </div>

        {/* Right — taped index card with a sample problem */}
        <div className="relative hidden lg:block">
          <div
            className="rounded-lg p-7 squared rotate-3 relative"
            style={{ background: "var(--card)", boxShadow: "0 16px 40px rgba(68,57,44,0.18)" }}
          >
            {/* washi tape */}
            <span
              className="absolute -top-4 left-1/2 -translate-x-1/2 w-28 h-7 rotate-2"
              style={{ background: "rgba(255,209,82,0.7)", boxShadow: "0 2px 6px rgba(0,0,0,0.08)" }}
            />
            <p className="handw text-2xl mb-4" style={{ color: "var(--pen-red)" }}>
              Mai feladat:
            </p>
            <p className="handw text-4xl mb-3" style={{ color: "var(--pen-blue)" }}>
              Ha 3x = 21,
            </p>
            <p className="handw text-4xl mb-5" style={{ color: "var(--pen-blue)" }}>
              akkor x = ?
            </p>
            <p className="handw text-3xl" style={{ color: "var(--ink)" }}>
              x = 7 &nbsp;<span style={{ color: "var(--pen-red)" }}>✓ Szuper!</span>
            </p>
          </div>
          {/* floating doodles */}
          <span className="absolute -bottom-8 -left-6 handw text-5xl -rotate-12" style={{ color: "var(--pen-blue)", opacity: 0.5 }}>π</span>
          <span className="absolute -top-10 -right-4 handw text-5xl rotate-12" style={{ color: "var(--pen-red)", opacity: 0.5 }}>√</span>
        </div>
      </div>
    </section>
  );
}
