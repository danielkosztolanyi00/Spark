"use client";

const floaters = [
  { sym: "π", top: "18%", left: "8%", size: "2.4rem", color: "var(--teal)", delay: "0s" },
  { sym: "√", top: "62%", left: "12%", size: "2rem", color: "var(--rust)", delay: "1.2s" },
  { sym: "∑", top: "26%", right: "10%", size: "2.6rem", color: "var(--mustard)", delay: "0.6s" },
  { sym: "∫", top: "70%", right: "14%", size: "2.2rem", color: "var(--teal)", delay: "1.8s" },
  { sym: "x²", top: "48%", right: "6%", size: "1.6rem", color: "var(--rust)", delay: "0.9s" },
  { sym: "%", top: "82%", left: "44%", size: "1.5rem", color: "var(--mustard)", delay: "1.5s" },
];

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden graph-paper" style={{ background: "var(--paper)" }}>
      {/* warm glow */}
      <div
        className="absolute -top-32 -right-32 w-[500px] h-[500px] rounded-full blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(210,96,58,0.16) 0%, transparent 70%)" }}
      />
      <div
        className="absolute -bottom-40 -left-20 w-[420px] h-[420px] rounded-full blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(47,125,107,0.12) 0%, transparent 70%)" }}
      />

      {/* floating math symbols */}
      {floaters.map((f, i) => (
        <span
          key={i}
          className="absolute font-display font-bold pointer-events-none select-none opacity-60 hidden sm:block"
          style={{
            top: f.top,
            left: f.left,
            right: f.right,
            fontSize: f.size,
            color: f.color,
            animation: `float-slow 7s ease-in-out infinite`,
            animationDelay: f.delay,
          }}
        >
          {f.sym}
        </span>
      ))}

      <div className="max-w-4xl mx-auto px-6 py-32 relative text-center">
        <div
          className="inline-flex items-center gap-2 rounded-full px-4 py-2 mb-7 text-sm font-bold"
          style={{ background: "var(--teal-soft)", border: "1px solid rgba(47,125,107,0.25)", color: "var(--teal)" }}
        >
          🎓 30+ év a középiskolai katedrán
        </div>

        <h1 className="font-display font-bold leading-[1.05] mb-6" style={{ color: "var(--ink)", fontSize: "clamp(2.5rem, 6vw, 4.25rem)" }}>
          A matek nem nehéz —<br />
          csak még nem magyarázta el{" "}
          <span className="relative inline-block" style={{ color: "var(--rust)" }}>
            jól
            <svg className="absolute left-0 -bottom-2 w-full" height="12" viewBox="0 0 200 12" fill="none" preserveAspectRatio="none">
              <path d="M2 8C50 2 150 2 198 8" stroke="var(--mustard)" strokeWidth="4" strokeLinecap="round" />
            </svg>
          </span>{" "}
          senki.
        </h1>

        <p className="text-lg sm:text-xl leading-relaxed mb-9 max-w-2xl mx-auto" style={{ color: "var(--ink-soft)" }}>
          Egyéni matematika korrepetálás Szegeden és online. Érettségi felkészítés közép- és
          emelt szinten, versenyfelkészítés és általános fejlesztés — türelmesen, lépésről lépésre,
          a te tempódban.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#kapcsolat"
            className="font-bold px-8 py-4 rounded-full text-lg no-underline transition-transform hover:scale-105"
            style={{ background: "var(--rust)", color: "#fff", boxShadow: "0 8px 24px rgba(210,96,58,0.3)" }}
          >
            Foglald le az ingyenes órát →
          </a>
          <a
            href="#talald-meg"
            className="font-bold px-8 py-4 rounded-full text-lg no-underline transition-all"
            style={{ background: "transparent", color: "var(--ink)", border: "2px solid var(--border)" }}
          >
            🔍 Próbáld ki: Találd meg a hibát!
          </a>
        </div>

        <div className="mt-12 flex flex-wrap gap-x-8 gap-y-3 justify-center text-sm font-semibold" style={{ color: "var(--ink-soft)" }}>
          <span>✨ Az első <b style={{ color: "var(--ink)" }}>2 óra ingyenes</b></span>
          <span>📐 Egyénre szabott feladatok</span>
          <span>📈 Bizonyított eredmények</span>
        </div>
      </div>
    </section>
  );
}
