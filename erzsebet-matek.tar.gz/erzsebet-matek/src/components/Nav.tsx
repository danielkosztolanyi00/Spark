"use client";
import { useEffect, useState } from "react";

const links = [
  { label: "Rólam", href: "#rolam" },
  { label: "Szolgáltatások", href: "#szolgaltatasok" },
  { label: "Találd meg a hibát", href: "#talald-meg" },
  { label: "Vélemények", href: "#velemenyek" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(251,246,238,0.92)" : "transparent",
        backdropFilter: scrolled ? "blur(10px)" : "none",
        borderBottom: scrolled ? "1px solid var(--border)" : "1px solid transparent",
      }}
    >
      <div className="max-w-6xl mx-auto px-6 h-18 py-4 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2.5 no-underline">
          <span
            className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold"
            style={{ background: "var(--rust)", color: "#fff", fontFamily: "Fraunces, serif" }}
          >
            √
          </span>
          <span className="leading-tight">
            <span className="block font-display font-bold text-lg" style={{ color: "var(--ink)" }}>
              Erzsébet
            </span>
            <span className="block text-xs font-semibold tracking-wide" style={{ color: "var(--ink-soft)" }}>
              matematika &middot; egyéni órák
            </span>
          </span>
        </a>

        <div className="hidden md:flex items-center gap-7">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-semibold transition-colors no-underline hover:opacity-70"
              style={{ color: "var(--ink)" }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#kapcsolat"
            className="text-sm font-bold px-5 py-2.5 rounded-full no-underline transition-transform hover:scale-105"
            style={{ background: "var(--rust)", color: "#fff" }}
          >
            Ingyenes első óra
          </a>
        </div>

        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setOpen((v) => !v)}
          aria-label="Menü"
        >
          <span className="w-6 h-0.5 rounded" style={{ background: "var(--ink)" }} />
          <span className="w-6 h-0.5 rounded" style={{ background: "var(--ink)" }} />
          <span className="w-6 h-0.5 rounded" style={{ background: "var(--ink)" }} />
        </button>
      </div>

      {open && (
        <div className="md:hidden px-6 pb-5 flex flex-col gap-3" style={{ background: "rgba(251,246,238,0.97)" }}>
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-sm font-semibold py-1 no-underline"
              style={{ color: "var(--ink)" }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#kapcsolat"
            onClick={() => setOpen(false)}
            className="text-sm font-bold px-5 py-3 rounded-full text-center no-underline"
            style={{ background: "var(--rust)", color: "#fff" }}
          >
            Ingyenes első óra
          </a>
        </div>
      )}
    </nav>
  );
}
