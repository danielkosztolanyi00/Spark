const services = [
  {
    emoji: "🎓",
    title: "Érettségi felkészítés",
    desc: "Közép- és emelt szintre egyaránt. Témakörről témakörre haladunk, sok korábbi feladatsorral — hogy a vizsgán már ne érjen meglepetés.",
    points: ["Közép- és emelt szint", "Régi feladatsorok", "Vizsgastratégia"],
    rot: "-2deg",
    tape: "rgba(255,209,82,0.75)",
    pen: "var(--pen-blue)",
  },
  {
    emoji: "🏆",
    title: "Versenyfelkészítés",
    desc: "A kíváncsi, tehetséges diákoknak. Megtanuljuk több oldalról nézni ugyanazt a feladatot — és élvezni a fejtörőket.",
    points: ["Logika & kombinatorika", "Bizonyítási ötletek", "Versenyrutin"],
    rot: "1.5deg",
    tape: "rgba(207,82,64,0.55)",
    pen: "var(--pen-red)",
  },
  {
    emoji: "🌱",
    title: "Általános fejlesztés",
    desc: "Ha valahol elcsúszott a tananyag, visszamegyünk az alapokig, és újraépítjük a magabiztosságot. Cél: a matek legyen érthető és kezelhető.",
    points: ["Hiánypótlás az alapoktól", "Dolgozatra készülés", "Önbizalom-építés"],
    rot: "-1deg",
    tape: "rgba(47,93,138,0.4)",
    pen: "var(--pen-blue)",
  },
];

export default function Services() {
  return (
    <section id="szolgaltatasok" className="py-24 px-6 relative" style={{ background: "var(--paper-2)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="handw text-2xl mb-1 rotate-1" style={{ color: "var(--pen-red)" }}>
            Miben segítek?
          </p>
          <h2 className="handw font-bold text-5xl" style={{ color: "var(--ink)" }}>
            Háromféle úton, egy közös céllal ✨
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((s) => (
            <div
              key={s.title}
              className="relative rounded-lg p-7 squared transition-transform hover:-translate-y-1.5 hover:rotate-0"
              style={{ background: "var(--card)", boxShadow: "0 12px 30px rgba(68,57,44,0.12)", transform: `rotate(${s.rot})` }}
            >
              {/* tape */}
              <span
                className="absolute -top-3 left-8 w-20 h-6 -rotate-3"
                style={{ background: s.tape, boxShadow: "0 2px 5px rgba(0,0,0,0.06)" }}
              />
              <div className="text-4xl mb-3">{s.emoji}</div>
              <h3 className="handw font-bold text-3xl mb-3" style={{ color: s.pen }}>
                {s.title}
              </h3>
              <p className="text-sm leading-relaxed mb-4" style={{ color: "var(--ink-soft)" }}>
                {s.desc}
              </p>
              <ul className="flex flex-col gap-2">
                {s.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 text-sm font-bold" style={{ color: "var(--ink)" }}>
                    <span className="handw text-xl leading-none" style={{ color: "var(--pen-red)" }}>✓</span>
                    {p}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* free lessons note as a sticky */}
        <div className="mt-14 flex justify-center">
          <div
            className="sticky rounded-sm px-9 py-7 max-w-lg text-center rotate-1"
            style={{ background: "var(--highlight-soft)" }}
          >
            <p className="handw text-3xl font-bold mb-1" style={{ color: "var(--ink)" }}>
              Az első két óra ingyen! 🎁
            </p>
            <p className="text-sm leading-relaxed" style={{ color: "var(--ink-soft)" }}>
              Megismerkedünk, megnézzük hol tartasz, és csinálunk egy tervet — kötelezettség nélkül.
              A további órák ára <b style={{ color: "var(--ink)" }}>megegyezés szerint</b>.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
