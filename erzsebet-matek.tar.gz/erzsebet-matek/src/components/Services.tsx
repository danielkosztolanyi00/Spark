const services = [
  {
    icon: "🎓",
    glyph: "∫",
    title: "Érettségi felkészítés",
    desc: "Közép- és emelt szintű érettségire való célzott felkészítés. Témakörről témakörre építjük fel a tudást, korábbi feladatsorokkal gyakorolva — hogy a vizsgán már semmi ne legyen meglepetés.",
    points: ["Közép- és emelt szint", "Korábbi feladatsorok elemzése", "Vizsgastratégia és időbeosztás"],
    color: "var(--rust)",
    soft: "var(--rust-soft)",
  },
  {
    icon: "🏆",
    glyph: "∑",
    title: "Versenyfelkészítés",
    desc: "A tehetséges, érdeklődő diákoknak: tanulmányi versenyekre való felkészítés a gondolkodtató, kreatív feladatok világában. Megtanuljuk, hogyan kell egy problémát több oldalról megközelíteni.",
    points: ["Logikai és kombinatorikai feladatok", "Bizonyítási technikák", "Versenyrutin fejlesztése"],
    color: "var(--teal)",
    soft: "var(--teal-soft)",
  },
  {
    icon: "📈",
    glyph: "π",
    title: "Általános fejlesztés",
    desc: "Ha valahol elcsúszott a tananyag, vagy csak magabiztosabbá szeretnél válni — visszamegyünk az alapokig, és újraépítjük a magabiztosságot. A cél, hogy a matek érthető és kezelhető legyen.",
    points: ["Hiányok pótlása az alapoktól", "Házifeladat- és dolgozatsegítség", "Önbizalom-építés"],
    color: "var(--mustard)",
    soft: "rgba(224,167,63,0.14)",
  },
];

export default function Services() {
  return (
    <section id="szolgaltatasok" className="py-24 px-6 relative dotted" style={{ background: "var(--paper-2)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-sm font-bold tracking-widest uppercase mb-3" style={{ color: "var(--rust)" }}>
            Amiben segítek
          </p>
          <h2 className="font-display font-bold text-4xl" style={{ color: "var(--ink)" }}>
            Háromféle úton, egy közös céllal
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-7">
          {services.map((s) => (
            <div
              key={s.title}
              className="relative rounded-3xl p-8 flex flex-col gap-4 overflow-hidden transition-transform hover:-translate-y-1.5"
              style={{ background: "var(--card)", border: "1px solid var(--border)", boxShadow: "0 4px 24px rgba(59,47,42,0.05)" }}
            >
              <span
                className="absolute -top-4 -right-2 font-display font-bold opacity-10 select-none"
                style={{ fontSize: "7rem", color: s.color }}
              >
                {s.glyph}
              </span>
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl"
                style={{ background: s.soft }}
              >
                {s.icon}
              </div>
              <h3 className="font-display font-bold text-2xl" style={{ color: "var(--ink)" }}>
                {s.title}
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: "var(--ink-soft)" }}>
                {s.desc}
              </p>
              <ul className="flex flex-col gap-2 mt-1">
                {s.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 text-sm font-semibold" style={{ color: "var(--ink)" }}>
                    <span style={{ color: s.color }}>✓</span>
                    {p}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 max-w-3xl mx-auto rounded-3xl p-8 text-center relative overflow-hidden" style={{ background: "var(--ink)", color: "var(--paper)" }}>
          <p className="font-display text-2xl font-bold mb-2">Az első két óra ingyenes 🎁</p>
          <p className="text-sm opacity-80 leading-relaxed">
            Ismerkedjünk meg, nézzük meg, hol tartasz, és állítsunk össze egy tervet — kötelezettség nélkül.
            A további órák ára <b>megegyezés szerint</b>, mindig a célhoz és az óraszámhoz igazítva.
          </p>
        </div>
      </div>
    </section>
  );
}
