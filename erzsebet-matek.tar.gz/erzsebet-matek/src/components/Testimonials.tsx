const testimonials = [
  {
    name: "Anna",
    role: "végzős, emelt érettségi",
    text: "Év elején még a négyestől is féltem. Erzsébet türelmesen újraépítette az alapokat, és a végén 88%-ot értem el emelt szinten. Tényleg megszerettette velem a matekot!",
    bg: "var(--highlight-soft)",
    rot: "-3deg",
  },
  {
    name: "Péter édesanyja",
    role: "szülő",
    text: "A fiam teljesen elveszett matekból. Hétről hétre visszatért az önbizalma — nem csak a jegyei javultak, hanem újra szívesen ült le tanulni. Ez mindennél többet ér.",
    bg: "#cfe3d8",
    rot: "2deg",
  },
  {
    name: "Bence",
    role: "versenyre készülő diák",
    text: "Nem feladatokat magoltunk, hanem megtanított gondolkodni — több irányból nézni ugyanazt. Bejutottam az országos döntőbe! 🏆",
    bg: "#f6d4cb",
    rot: "-1.5deg",
  },
];

export default function Testimonials() {
  return (
    <section id="velemenyek" className="py-24 px-6 squared" style={{ background: "var(--paper)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <p className="handw text-2xl rotate-1" style={{ color: "var(--pen-red)" }}>
            Amit mondanak…
          </p>
          <h2 className="handw font-bold text-5xl" style={{ color: "var(--ink)" }}>
            Diákok &amp; szülők üzenőfala 📌
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="sticky rounded-sm p-7 relative transition-transform hover:rotate-0 hover:scale-105"
              style={{ background: t.bg, transform: `rotate(${t.rot})` }}
            >
              {/* pushpin */}
              <span
                className="absolute -top-3 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full"
                style={{ background: "var(--pen-red)", boxShadow: "0 2px 4px rgba(0,0,0,0.25)", border: "2px solid #fff" }}
              />
              <p className="handw text-2xl leading-snug mb-5" style={{ color: "var(--ink)" }}>
                „{t.text}"
              </p>
              <div className="pt-3" style={{ borderTop: "1.5px dashed rgba(68,57,44,0.25)" }}>
                <div className="handw font-bold text-2xl" style={{ color: "var(--ink)" }}>
                  {t.name}
                </div>
                <div className="text-xs font-bold" style={{ color: "var(--ink-soft)" }}>
                  {t.role} · ★★★★★
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
