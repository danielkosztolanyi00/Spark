const testimonials = [
  {
    name: "Kovács Anna",
    role: "végzős diák, emelt szintű érettségi",
    text: "Év elején még a négyestől is rettegtem, az emelt szintet meg sem mertem említeni otthon. Erzsébet néni türelmesen újraépítette az alapokat, és a végén 88%-ot értem el emelt szinten. Tényleg megszerettette velem a matekot.",
    stars: 5,
    color: "var(--rust)",
  },
  {
    name: "Nagy Péterné",
    role: "szülő",
    text: "A fiam matekból teljesen elveszett a gimi második évében. Erzsébetnél hétről hétre visszatért az önbizalma — nem csak a jegyei javultak, hanem újra szívesen ült le tanulni. Ez nekünk többet ér mindennél.",
    stars: 5,
    color: "var(--teal)",
  },
  {
    name: "Szabó Bence",
    role: "versenyre készülő diák",
    text: "A megyei versenyre készültem vele. Nem egyszerűen feladatokat oldottunk meg, hanem megtanított gondolkodni — több irányból nézni ugyanazt a problémát. Bejutottam az országos döntőbe!",
    stars: 5,
    color: "var(--mustard)",
  },
];

export default function Testimonials() {
  return (
    <section id="velemenyek" className="py-24 px-6" style={{ background: "var(--paper-2)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-sm font-bold tracking-widest uppercase mb-3" style={{ color: "var(--rust)" }}>
            Vélemények
          </p>
          <h2 className="font-display font-bold text-4xl" style={{ color: "var(--ink)" }}>
            Amit a diákok és a szülők mondanak
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-7">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="rounded-3xl p-8 flex flex-col gap-4 relative overflow-hidden"
              style={{ background: "var(--card)", border: "1px solid var(--border)", boxShadow: "0 4px 24px rgba(59,47,42,0.05)" }}
            >
              <span className="font-display font-bold text-6xl leading-none" style={{ color: t.color, opacity: 0.25 }}>
                &ldquo;
              </span>
              <p className="text-sm leading-relaxed flex-1 -mt-4" style={{ color: "var(--ink-soft)" }}>
                {t.text}
              </p>
              <div className="flex gap-0.5">
                {Array.from({ length: t.stars }).map((_, i) => (
                  <span key={i} style={{ color: "var(--mustard)" }}>
                    ★
                  </span>
                ))}
              </div>
              <div className="pt-4" style={{ borderTop: "1px solid var(--border)" }}>
                <div className="font-display font-bold" style={{ color: "var(--ink)" }}>
                  {t.name}
                </div>
                <div className="text-xs font-semibold" style={{ color: "var(--ink-soft)" }}>
                  {t.role}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
