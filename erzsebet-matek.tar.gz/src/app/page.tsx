import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import About from "@/components/About";
import FindTheMistake from "@/components/FindTheMistake";
import Testimonials from "@/components/Testimonials";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Nav />
      <Hero />
      <Services />
      <About />
      <FindTheMistake />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
}
