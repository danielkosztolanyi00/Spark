const stats = [
  { num: "30+", label: "év a katedrán", rot: "-3deg", bg: "var(--highlight-soft)" },
  { num: "200+", label: "diák felkészítve", rot: "2deg", bg: "#cfe3d8" },
  { num: "100%", label: "türelem 😊", rot: "-2deg", bg: "#f6d4cb" },
];

export default function About() {
  return (
    <section id="rolam" className="py-24 px-6 squared" style={{ background: "var(--paper)" }}>
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        {/* Polaroid */}
        <div className="flex justify-center">
          <div className="relative">
            <div
              className="p-4 pb-16 rotate-[-4deg] paper-shadow"
              style={{ background: "#fffdf8" }}
            >
              {/* washi tape top */}
              <span
                className="absolute -top-4 left-1/2 -translate-x-1/2 w-32 h-8 rotate-2"
                style={{ background: "rgba(47,93,138,0.35)", boxShadow: "0 2px 6px rgba(0,0,0,0.08)" }}
              />
              <div
                className="w-64 h-72 sm:w-72 sm:h-80 flex items-center justify-center"
                style={{ background: "var(--paper-2)" }}
              >
                <span className="handw text-9xl" style={{ color: "var(--pen-blue)", opacity: 0.5 }}>
                  E
                </span>
              </div>
              <p className="handw text-3xl text-center mt-3" style={{ color: "var(--ink)" }}>
                Itt kezdődik a megértés
              </p>
            </div>
          </div>
        </div>

        {/* Story */}
        <div>
          <p className="handw text-2xl mb-1 -rotate-1" style={{ color: "var(--pen-red)" }}>
            Pár szó rólam…
          </p>
          <h2 className="handw font-bold text-5xl leading-tight mb-6" style={{ color: "var(--ink)" }}>
            Imádom azt a pillanatot, amikor leesik a tantusz
          </h2>
          <div className="flex flex-col gap-4 text-base leading-relaxed" style={{ color: "var(--ink-soft)" }}>
            <p>
              Több mint <b style={{ color: "var(--ink)" }}>három évtizedet</b> tanítottam
              középiskolában matematikát. Dolgoztam már a megbukástól rettegő diákkal és az
              országos versenyre készülővel is — és mindkettőt ugyanúgy szeretem.
            </p>
            <p>
              A leghasznosabb, amit megtanultam: <span className="marker">nincs „nem matekos fej"</span>.
              Csak jó és kevésbé jó magyarázat van. Az egyéni órákon mindig megkeressük azt a
              szálat, amin keresztül neked is összeáll a kép.
            </p>
            <p>
              Sok tanítványom ért el szép eredményt érettségin és felvételin — de a kedvenc
              pillanatom mindig az, amikor valaki először mondja: „<i>áá, hát ez ennyire egyszerű?</i>"
            </p>
          </div>

          <div className="flex flex-wrap gap-5 mt-9">
            {stats.map((s) => (
              <div
                key={s.label}
                className="sticky rounded-sm px-6 py-4 text-center"
                style={{ background: s.bg, transform: `rotate(${s.rot})` }}
              >
                <div className="handw font-bold text-4xl" style={{ color: "var(--ink)" }}>
                  {s.num}
                </div>
                <div className="text-xs font-bold" style={{ color: "var(--ink-soft)" }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
