"use client";
import { useEffect, useState } from "react";

const links = [
  { label: "Rólam", href: "#rolam" },
  { label: "Miben segítek", href: "#szolgaltatasok" },
  { label: "Kvíz", href: "#talald-meg" },
  { label: "Vélemények", href: "#velemenyek" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(253,245,228,0.92)" : "transparent",
        backdropFilter: scrolled ? "blur(8px)" : "none",
        borderBottom: scrolled ? "2px dashed var(--border)" : "2px dashed transparent",
      }}
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2.5 no-underline">
          <span
            className="w-11 h-11 rounded-2xl flex items-center justify-center text-2xl handw font-bold -rotate-6"
            style={{ background: "var(--pen-blue)", color: "var(--chalk)" }}
          >
            ε
          </span>
          <span className="handw font-bold text-2xl leading-none" style={{ color: "var(--ink)" }}>
            Magán Matek Oktatás
          </span>
        </a>

        <div className="hidden md:flex items-center gap-7">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-bold transition-colors no-underline hover:opacity-70"
              style={{ color: "var(--ink)" }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#kapcsolat"
            className="handw text-xl font-bold px-5 py-1.5 rounded-full no-underline transition-transform hover:scale-105 rotate-2"
            style={{ background: "var(--pen-red)", color: "var(--chalk)" }}
          >
            Ingyenes első óra!
          </a>
        </div>

        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setOpen((v) => !v)}
          aria-label="Menü"
        >
          <span className="w-6 h-0.5 rounded" style={{ background: "var(--ink)" }} />
          <span className="w-6 h-0.5 rounded" style={{ background: "var(--ink)" }} />
          <span className="w-6 h-0.5 rounded" style={{ background: "var(--ink)" }} />
        </button>
      </div>

      {open && (
        <div className="md:hidden px-6 pb-5 flex flex-col gap-3" style={{ background: "rgba(253,245,228,0.98)" }}>
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-sm font-bold py-1 no-underline"
              style={{ color: "var(--ink)" }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#kapcsolat"
            onClick={() => setOpen(false)}
            className="handw text-xl font-bold px-5 py-2 rounded-full text-center no-underline"
            style={{ background: "var(--pen-red)", color: "var(--chalk)" }}
          >
            Ingyenes első óra!
          </a>
        </div>
      )}
    </nav>
  );
}
