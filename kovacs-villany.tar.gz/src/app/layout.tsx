import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kovács Villanyszerelés | Megbízható villamos munkák Szegeden",
  description:
    "30 éve megbízható villanyszerelési szolgáltatások Szegeden és környékén. Általános villanyszerelés, lakás-átvezetékezés, napelem telepítés. Ingyenes felmérés!",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="hu">
      <body>{children}</body>
    </html>
  );
}
