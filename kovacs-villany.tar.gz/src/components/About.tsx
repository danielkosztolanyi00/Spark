const stats = [
  { number: "30+", label: "év tapasztalat" },
  { number: "600+", label: "elégedett ügyfél" },
  { number: "2", label: "generáció" },
  { number: "100%", label: "engedéllyel végzett" },
];

export default function About() {
  return (
    <section id="rolunk" className="py-24 px-6" style={{ background: "#fff" }}>
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        {/* Left — story */}
        <div>
          <p className="text-sm font-semibold tracking-widest uppercase mb-4" style={{ color: "#f59e0b" }}>
            Rólunk
          </p>
          <h2 className="text-4xl font-bold leading-tight mb-6" style={{ color: "#1c3557" }}>
            Szegedi családi vállalkozás,{" "}
            <span style={{ color: "#f59e0b" }}>két generáció</span> tudásával
          </h2>
          <p className="text-base leading-relaxed mb-4" style={{ color: "#475569" }}>
            Kovács István 1993-ban alapította a vállalkozást, miután 15 évet dolgozott
            állami vállalatnál villamos mérnökként. Azzal a céllal kezdett önállósodni,
            hogy szegedi szomszédainak ugyanolyan minőségű munkát végezzen, mint amit
            a nagyvárosokban megszokott — csak személyesen, megbízhatóan.
          </p>
          <p className="text-base leading-relaxed mb-8" style={{ color: "#475569" }}>
            Ma már fia, Kovács Péter is a csapat tagja. Együtt vállalnak el mindent a
            kis lakásjavítástól a komplex napelemes rendszerek telepítéséig. Az ügyfelek
            nagy része évek óta visszatérő — ez a legjobb visszajelzés, amit kaphatunk.
          </p>

          <div className="flex flex-col gap-3">
            {[
              "Magyar Kereskedelmi és Iparkamara tag",
              "MAVIR hálózati csatlakozási engedély",
              "Felelősségbiztosítással rendelkezünk",
            ].map((item) => (
              <div key={item} className="flex items-center gap-3 text-sm" style={{ color: "#475569" }}>
                <span
                  className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                  style={{ background: "#f59e0b", color: "#1c3557" }}
                >
                  ✓
                </span>
                {item}
              </div>
            ))}
          </div>
        </div>

        {/* Right — stats */}
        <div className="grid grid-cols-2 gap-6">
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-2xl p-8 text-center"
              style={{ background: "#1c3557" }}
            >
              <div className="text-4xl font-bold mb-2" style={{ color: "#f59e0b" }}>
                {s.number}
              </div>
              <div className="text-sm font-medium" style={{ color: "rgba(255,255,255,0.7)" }}>
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
