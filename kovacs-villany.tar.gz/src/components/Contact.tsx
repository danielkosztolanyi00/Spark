"use client";
export default function Contact() {
  return (
    <section id="kapcsolat" className="py-24 px-6" style={{ background: "#1c3557" }}>
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-16 items-start">
        {/* Left */}
        <div>
          <p className="text-sm font-semibold tracking-widest uppercase mb-4" style={{ color: "#f59e0b" }}>
            Kapcsolat
          </p>
          <h2 className="text-4xl font-bold text-white leading-tight mb-6">
            Kérjen ingyenes{" "}
            <span style={{ color: "#f59e0b" }}>helyszíni felmérést</span>
          </h2>
          <p className="text-base leading-relaxed mb-10" style={{ color: "rgba(255,255,255,0.65)" }}>
            Írjon vagy hívjon minket — 24 órán belül visszajelzünk, és egyeztetünk
            egy megfelelő időpontot. A felmérés minden esetben ingyenes és kötelezettségmentes.
          </p>

          <div className="flex flex-col gap-5">
            {[
              { icon: "📞", label: "Telefon", value: "+36 70 000 0000", href: "tel:+36700000000" },
              { icon: "📧", label: "E-mail", value: "info@kovacsvillany.hu", href: "mailto:info@kovacsvillany.hu" },
              { icon: "📍", label: "Iroda", value: "6720 Szeged, Minta utca 1.", href: null },
              { icon: "🕐", label: "Nyitvatartás", value: "H–P: 7:00–18:00 · Szo: 8:00–13:00", href: null },
            ].map((item) => (
              <div key={item.label} className="flex gap-4 items-start">
                <span className="text-xl mt-0.5">{item.icon}</span>
                <div>
                  <div className="text-xs font-medium mb-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>
                    {item.label}
                  </div>
                  {item.href ? (
                    <a href={item.href} className="font-semibold text-white hover:underline" style={{ color: "#f59e0b" }}>
                      {item.value}
                    </a>
                  ) : (
                    <span className="font-medium text-white">{item.value}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right — form */}
        <form
          className="rounded-2xl p-8 flex flex-col gap-5"
          style={{ background: "#fff" }}
          onSubmit={(e) => e.preventDefault()}
        >
          <h3 className="text-xl font-bold" style={{ color: "#1c3557" }}>
            Küldjön üzenetet
          </h3>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium" style={{ color: "#1c3557" }}>Neve</label>
              <input
                type="text"
                placeholder="Kovács János"
                className="px-4 py-3 rounded-xl text-sm outline-none transition-all"
                style={{ border: "1.5px solid #e2e8f0", color: "#1c3557" }}
                onFocus={(e) => (e.currentTarget.style.borderColor = "#f59e0b")}
                onBlur={(e) => (e.currentTarget.style.borderColor = "#e2e8f0")}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium" style={{ color: "#1c3557" }}>Telefonszám</label>
              <input
                type="tel"
                placeholder="+36 30 123 4567"
                className="px-4 py-3 rounded-xl text-sm outline-none transition-all"
                style={{ border: "1.5px solid #e2e8f0", color: "#1c3557" }}
                onFocus={(e) => (e.currentTarget.style.borderColor = "#f59e0b")}
                onBlur={(e) => (e.currentTarget.style.borderColor = "#e2e8f0")}
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium" style={{ color: "#1c3557" }}>Milyen munkára van szüksége?</label>
            <select
              className="px-4 py-3 rounded-xl text-sm outline-none transition-all"
              style={{ border: "1.5px solid #e2e8f0", color: "#1c3557" }}
            >
              <option value="">Válasszon...</option>
              <option>Általános villanyszerelés / javítás</option>
              <option>Teljes átvezetékezés</option>
              <option>Napelem telepítés</option>
              <option>Egyéb / nem tudom pontosan</option>
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium" style={{ color: "#1c3557" }}>Üzenet (opcionális)</label>
            <textarea
              rows={4}
              placeholder="Rövid leírás a munkáról, helyszínről..."
              className="px-4 py-3 rounded-xl text-sm outline-none transition-all resize-none"
              style={{ border: "1.5px solid #e2e8f0", color: "#1c3557" }}
              onFocus={(e) => (e.currentTarget.style.borderColor = "#f59e0b")}
              onBlur={(e) => (e.currentTarget.style.borderColor = "#e2e8f0")}
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 rounded-xl font-bold text-base transition-opacity hover:opacity-90"
            style={{ background: "#f59e0b", color: "#1c3557" }}
          >
            Üzenet küldése →
          </button>

          <p className="text-xs text-center" style={{ color: "#94a3b8" }}>
            24 órán belül visszajelzünk. A felmérés ingyenes és kötelezettségmentes.
          </p>
        </form>
      </div>
    </section>
  );
}
