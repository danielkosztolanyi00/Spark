export default function Footer() {
  return (
    <footer className="py-10 px-6" style={{ background: "#0f1e35", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center"
            style={{ background: "#1c3557", border: "1.5px solid rgba(245,158,11,0.4)" }}
          >
            <svg viewBox="0 0 24 24" width="16" height="16" fill="#f59e0b" aria-hidden>
              <path d="M13 2L4.5 13H11L10 22L19.5 11H13L13 2Z" />
            </svg>
          </div>
          <div>
            <div className="text-white font-bold text-sm">Kovács Villanyszerelés</div>
            <div className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>Szeged, 1993–</div>
          </div>
        </div>

        <div className="flex gap-6 text-sm" style={{ color: "rgba(255,255,255,0.4)" }}>
          <a href="#szolgaltatasok" className="hover:text-white transition-colors">Szolgáltatások</a>
          <a href="#rolunk" className="hover:text-white transition-colors">Rólunk</a>
          <a href="#kapcsolat" className="hover:text-white transition-colors">Kapcsolat</a>
        </div>

        <div className="text-xs text-center md:text-right" style={{ color: "rgba(255,255,255,0.3)" }}>
          © {new Date().getFullYear()} Kovács Villanyszerelés Kft.<br />
          6720 Szeged, Minta utca 1.
        </div>
      </div>
    </footer>
  );
}
