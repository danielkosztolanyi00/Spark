"use client";
export default function Hero() {
  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ background: "linear-gradient(135deg, #1c3557 0%, #152843 60%, #0f1e35 100%)" }}
    >
      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />
      {/* Amber glow */}
      <div
        className="absolute top-1/2 right-0 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(245,158,11,0.12) 0%, transparent 70%)" }}
      />

      <div className="max-w-6xl mx-auto px-6 py-32 relative w-full">
        <div className="max-w-2xl">
          <div
            className="inline-flex items-center gap-2 rounded-full px-4 py-2 mb-8 text-sm font-medium"
            style={{ background: "rgba(245,158,11,0.15)", border: "1px solid rgba(245,158,11,0.3)", color: "#f59e0b" }}
          >
            ⚡ Szegedi családi vállalkozás 1993 óta
          </div>

          <h1 className="text-5xl sm:text-6xl font-bold text-white leading-tight mb-6">
            Villanyszerelés,{" "}
            <span style={{ color: "#f59e0b" }}>amire számíthat</span>
          </h1>

          <p className="text-xl leading-relaxed mb-10" style={{ color: "rgba(255,255,255,0.7)" }}>
            30 éve végzünk megbízható villamos munkákat Szegeden és a
            Dél-Alföldön. Általános villanyszerelés, teljes átvezetékezés és
            napelem telepítés — szakszerűen, határidőre.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#kapcsolat"
              className="font-bold px-8 py-4 rounded-xl text-lg text-center transition-opacity hover:opacity-90"
              style={{ background: "#f59e0b", color: "#1c3557" }}
            >
              Ingyenes felmérés →
            </a>
            <a
              href="tel:+3662456789"
              className="font-semibold px-8 py-4 rounded-xl text-lg text-center text-white transition-all"
              style={{ border: "2px solid rgba(255,255,255,0.25)" }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.6)")}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.25)")}
            >
              📞 +36 62 456 789
            </a>
          </div>

          <div className="mt-12 flex flex-wrap gap-6">
            {[
              "✅ Engedéllyel rendelkező szerelők",
              "🛡️ Felelősségbiztosítással",
              "⏱️ Gyors kiszállás Szegeden",
            ].map((badge) => (
              <span key={badge} className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
                {badge}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
