"use client";

export default function Hero() {
  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ background: "linear-gradient(135deg, #1c3557 0%, #152843 60%, #0f1e35 100%)" }}
    >
      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      {/* Amber glow */}
      <div
        className="absolute top-1/2 right-0 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(245,158,11,0.12) 0%, transparent 70%)" }}
      />

      {/* Animated electrical wires — edge-only, away from text */}
      <svg
        viewBox="0 0 1000 600"
        className="absolute inset-0 w-full h-full pointer-events-none select-none"
        aria-hidden
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <style>{`
            @keyframes wire-flow-a { from { stroke-dashoffset: 48; } to { stroke-dashoffset: 0; } }
            @keyframes wire-flow-b { from { stroke-dashoffset: 48; } to { stroke-dashoffset: 0; } }
            @keyframes wire-flow-c { from { stroke-dashoffset: 48; } to { stroke-dashoffset: 0; } }
            @keyframes wire-flow-d { from { stroke-dashoffset: 48; } to { stroke-dashoffset: 0; } }
            @keyframes dot-pulse {
              0%, 100% { opacity: 0.15; }
              50%       { opacity: 0.55; }
            }
          `}</style>
        </defs>

        {/* Static skeleton — hugging top, bottom and right edges */}
        <g fill="none" stroke="#f59e0b" strokeWidth="1" opacity="0.07">
          {/* top edge */}
          <path d="M0,25 H160 V50 H340 V15 H560 V40 H780 V10 H1000" />
          <path d="M160,0 V50 M560,0 V40 M780,0 V10" />
          {/* bottom edge */}
          <path d="M0,575 H120 V550 H300 V585 H520 V560 H740 V580 H1000" />
          <path d="M120,600 V550 M520,600 V560 M740,600 V580" />
          {/* right side panel (x > 700) */}
          <path d="M980,50 V180 H920 V320 H970 V460 H900 V550" />
          <path d="M920,320 H860 V420 H810 V500" />
          <path d="M810,500 H750 V560" />
        </g>

        {/* Animated current — top edge */}
        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.5" opacity="0.3"
          strokeDasharray="8 40"
          d="M0,25 H160 V50 H340 V15 H560 V40 H780 V10 H1000"
          style={{ animation: "wire-flow-a 2.6s linear infinite" }}
        />

        {/* Animated current — bottom edge */}
        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.5" opacity="0.3"
          strokeDasharray="8 40"
          d="M0,575 H120 V550 H300 V585 H520 V560 H740 V580 H1000"
          style={{ animation: "wire-flow-b 3.2s linear infinite 1.1s" }}
        />

        {/* Animated current — right panel vertical */}
        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.2" opacity="0.28"
          strokeDasharray="6 36"
          d="M980,50 V180 H920 V320 H970 V460 H900 V550"
          style={{ animation: "wire-flow-c 2.2s linear infinite 0.5s" }}
        />

        {/* Animated current — right panel branch */}
        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.2" opacity="0.28"
          strokeDasharray="6 36"
          d="M920,320 H860 V420 H810 V500 H750 V560"
          style={{ animation: "wire-flow-d 2.9s linear infinite 1.6s" }}
        />

        {/* Junction dots */}
        {[
          [160, 50], [340, 15], [560, 40], [780, 10],
          [120, 550], [520, 560], [740, 580],
          [920, 180], [920, 320], [860, 420], [810, 500],
        ].map(([cx, cy], i) => (
          <circle
            key={i}
            cx={cx} cy={cy} r="2.5"
            fill="#f59e0b"
            style={{
              animation: `dot-pulse ${2 + (i % 4) * 0.4}s ease-in-out infinite`,
              animationDelay: `${i * 0.2}s`,
            }}
          />
        ))}
      </svg>

      <div className="max-w-6xl mx-auto px-6 py-32 relative w-full" style={{ zIndex: 10 }}>
        <div className="max-w-2xl">
          <div
            className="inline-flex items-center gap-2 rounded-full px-4 py-2 mb-8 text-sm font-medium"
            style={{ background: "rgba(245,158,11,0.15)", border: "1px solid rgba(245,158,11,0.3)", color: "#f59e0b" }}
          >
            ⚡ Szegedi családi vállalkozás 1993 óta
          </div>

          <h1 className="text-5xl sm:text-6xl font-bold text-white leading-tight mb-6">
            Villanyszerelés,{" "}
            <span style={{ color: "#f59e0b" }}>amire számíthat</span>
          </h1>

          <p className="text-xl leading-relaxed mb-10" style={{ color: "rgba(255,255,255,0.7)" }}>
            30 éve végzünk megbízható villamos munkákat Szegeden és a
            Dél-Alföldön. Általános villanyszerelés, teljes átvezetékezés és
            napelem telepítés — szakszerűen, határidőre.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#kapcsolat"
              className="font-bold px-8 py-4 rounded-xl text-lg text-center transition-opacity hover:opacity-90"
              style={{ background: "#f59e0b", color: "#1c3557" }}
            >
              Ingyenes felmérés →
            </a>
            <a
              href="tel:+36700000000"
              className="font-semibold px-8 py-4 rounded-xl text-lg text-center text-white transition-all"
              style={{ border: "2px solid rgba(255,255,255,0.25)" }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.6)")}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.25)")}
            >
              📞 +36 70 000 0000
            </a>
          </div>

          <div className="mt-12 flex flex-wrap gap-6">
            {[
              "✅ Engedéllyel rendelkező szerelők",
              "🛡️ Felelősségbiztosítással",
              "⏱️ Gyors kiszállás Szegeden",
            ].map((badge) => (
              <span key={badge} className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
                {badge}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1" style={{ zIndex: 10 }}>
        <span className="text-[10px] tracking-[0.25em] uppercase" style={{ color: "rgba(255,255,255,0.35)" }}>
          Tovább
        </span>
        {[0, 1, 2].map((i) => (
          <svg
            key={i}
            width="18" height="10" viewBox="0 0 18 10" fill="none"
            stroke="#f59e0b"
            strokeWidth="1.8"
            strokeLinecap="round"
            style={{
              opacity: 0,
              animation: `scroll-chevron 1.8s ease-in-out infinite`,
              animationDelay: `${i * 0.22}s`,
            }}
          >
            <path d="M1 1l8 7 8-7" />
            <style>{`
              @keyframes scroll-chevron {
                0%   { opacity: 0; transform: translateY(-4px); }
                40%  { opacity: 0.9; transform: translateY(0); }
                80%  { opacity: 0; transform: translateY(4px); }
                100% { opacity: 0; transform: translateY(4px); }
              }
            `}</style>
          </svg>
        ))}
      </div>
    </section>
  );
}
