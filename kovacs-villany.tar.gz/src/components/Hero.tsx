"use client";

export default function Hero() {
  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ background: "linear-gradient(135deg, #1c3557 0%, #152843 60%, #0f1e35 100%)" }}
    >
      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      {/* Amber glow */}
      <div
        className="absolute top-1/2 right-0 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(245,158,11,0.12) 0%, transparent 70%)" }}
      />

      {/* Animated electrical wires */}
      <svg
        viewBox="0 0 1000 600"
        className="absolute inset-0 w-full h-full pointer-events-none select-none"
        aria-hidden
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <style>{`
            @keyframes wire-flow-a {
              from { stroke-dashoffset: 48; }
              to   { stroke-dashoffset: 0; }
            }
            @keyframes wire-flow-b {
              from { stroke-dashoffset: 48; }
              to   { stroke-dashoffset: 0; }
            }
            @keyframes wire-flow-c {
              from { stroke-dashoffset: 48; }
              to   { stroke-dashoffset: 0; }
            }
            @keyframes wire-flow-d {
              from { stroke-dashoffset: 48; }
              to   { stroke-dashoffset: 0; }
            }
            @keyframes dot-pulse {
              0%, 100% { opacity: 0.25; r: 3; }
              50%       { opacity: 0.9;  r: 4.5; }
            }
          `}</style>
        </defs>

        {/* Static wire skeleton — very faint */}
        <g fill="none" stroke="#f59e0b" strokeWidth="1" opacity="0.12">
          <path d="M0,160 H220 V100 H460 V180 H720 V110 H1000" />
          <path d="M0,380 H160 V290 H380 V430 H640 V340 H860 V420 H1000" />
          <path d="M220,0 V160" />
          <path d="M460,0 V100" />
          <path d="M720,0 V110" />
          <path d="M160,600 V290" />
          <path d="M380,600 V430" />
          <path d="M640,600 V340" />
          <path d="M860,600 V420" />
        </g>

        {/* Animated current — horizontal wire A */}
        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.5"
          strokeDasharray="8 40"
          d="M0,160 H220 V100 H460 V180 H720 V110 H1000"
          style={{ animation: "wire-flow-a 2.4s linear infinite" }}
        />

        {/* Animated current — horizontal wire B */}
        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.5"
          strokeDasharray="8 40"
          d="M0,380 H160 V290 H380 V430 H640 V340 H860 V420 H1000"
          style={{ animation: "wire-flow-b 3.1s linear infinite 0.8s" }}
        />

        {/* Animated current — vertical drops */}
        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.2"
          strokeDasharray="6 36"
          d="M220,0 V160 M460,0 V100 M720,0 V110"
          style={{ animation: "wire-flow-c 2s linear infinite 0.4s" }}
        />

        <path
          fill="none" stroke="#f59e0b" strokeWidth="1.2"
          strokeDasharray="6 36"
          d="M160,600 V290 M380,600 V430 M640,600 V340 M860,600 V420"
          style={{ animation: "wire-flow-d 2.8s linear infinite 1.2s" }}
        />

        {/* Junction dots */}
        {[
          [220, 160], [460, 100], [720, 110],
          [160, 290], [380, 430], [640, 340], [860, 420],
        ].map(([cx, cy], i) => (
          <circle
            key={i}
            cx={cx} cy={cy} r="3"
            fill="#f59e0b"
            style={{
              animation: `dot-pulse ${1.8 + i * 0.3}s ease-in-out infinite`,
              animationDelay: `${i * 0.25}s`,
            }}
          />
        ))}
      </svg>

      <div className="max-w-6xl mx-auto px-6 py-32 relative w-full" style={{ zIndex: 10 }}>
        <div className="max-w-2xl">
          <div
            className="inline-flex items-center gap-2 rounded-full px-4 py-2 mb-8 text-sm font-medium"
            style={{ background: "rgba(245,158,11,0.15)", border: "1px solid rgba(245,158,11,0.3)", color: "#f59e0b" }}
          >
            ⚡ Szegedi családi vállalkozás 1993 óta
          </div>

          <h1 className="text-5xl sm:text-6xl font-bold text-white leading-tight mb-6">
            Villanyszerelés,{" "}
            <span style={{ color: "#f59e0b" }}>amire számíthat</span>
          </h1>

          <p className="text-xl leading-relaxed mb-10" style={{ color: "rgba(255,255,255,0.7)" }}>
            30 éve végzünk megbízható villamos munkákat Szegeden és a
            Dél-Alföldön. Általános villanyszerelés, teljes átvezetékezés és
            napelem telepítés — szakszerűen, határidőre.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#kapcsolat"
              className="font-bold px-8 py-4 rounded-xl text-lg text-center transition-opacity hover:opacity-90"
              style={{ background: "#f59e0b", color: "#1c3557" }}
            >
              Ingyenes felmérés →
            </a>
            <a
              href="tel:+36700000000"
              className="font-semibold px-8 py-4 rounded-xl text-lg text-center text-white transition-all"
              style={{ border: "2px solid rgba(255,255,255,0.25)" }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.6)")}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.25)")}
            >
              📞 +36 70 000 0000
            </a>
          </div>

          <div className="mt-12 flex flex-wrap gap-6">
            {[
              "✅ Engedéllyel rendelkező szerelők",
              "🛡️ Felelősségbiztosítással",
              "⏱️ Gyors kiszállás Szegeden",
            ].map((badge) => (
              <span key={badge} className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>
                {badge}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1" style={{ zIndex: 10 }}>
        <span className="text-[10px] tracking-[0.25em] uppercase" style={{ color: "rgba(255,255,255,0.35)" }}>
          Tovább
        </span>
        {[0, 1, 2].map((i) => (
          <svg
            key={i}
            width="18" height="10" viewBox="0 0 18 10" fill="none"
            stroke="#f59e0b"
            strokeWidth="1.8"
            strokeLinecap="round"
            style={{
              opacity: 0,
              animation: `scroll-chevron 1.8s ease-in-out infinite`,
              animationDelay: `${i * 0.22}s`,
            }}
          >
            <path d="M1 1l8 7 8-7" />
            <style>{`
              @keyframes scroll-chevron {
                0%   { opacity: 0; transform: translateY(-4px); }
                40%  { opacity: 0.9; transform: translateY(0); }
                80%  { opacity: 0; transform: translateY(4px); }
                100% { opacity: 0; transform: translateY(4px); }
              }
            `}</style>
          </svg>
        ))}
      </div>
    </section>
  );
}
