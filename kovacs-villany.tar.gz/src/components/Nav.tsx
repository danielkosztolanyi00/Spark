"use client";
import { useState, useEffect } from "react";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const links = [
    { href: "#szolgaltatasok", label: "Szolgáltatások" },
    { href: "#rolunk", label: "Rólunk" },
    { href: "#velemenyeik", label: "Vélemények" },
    { href: "#kapcsolat", label: "Kapcsolat" },
  ];

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{ background: scrolled ? "#1c3557" : "transparent", boxShadow: scrolled ? "0 2px 20px rgba(0,0,0,0.3)" : "none" }}
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="#" className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center"
            style={{ background: "#1c3557", border: "1.5px solid rgba(245,158,11,0.5)" }}
          >
            <svg viewBox="0 0 24 24" width="18" height="18" fill="#f59e0b" aria-hidden>
              <path d="M13 2L4.5 13H11L10 22L19.5 11H13L13 2Z" />
            </svg>
          </div>
          <div>
            <div className="text-white font-bold text-base leading-tight">Kovács Villanyszerelés</div>
            <div className="text-xs" style={{ color: "#f59e0b" }}>Szeged és környéke</div>
          </div>
        </a>

        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-white/75 hover:text-white text-sm transition-colors">
              {l.label}
            </a>
          ))}
          <a
            href="tel:+36700000000"
            className="font-bold px-5 py-2.5 rounded-xl text-sm transition-colors"
            style={{ background: "#f59e0b", color: "#1c3557" }}
          >
            📞 +36 70 000 0000
          </a>
        </div>

        <button className="md:hidden text-white p-1" onClick={() => setOpen(!open)}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {open
              ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
          </svg>
        </button>
      </div>

      {open && (
        <div className="md:hidden px-6 py-5 flex flex-col gap-4 border-t border-white/10" style={{ background: "#1c3557" }}>
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-white/80 hover:text-white" onClick={() => setOpen(false)}>
              {l.label}
            </a>
          ))}
          <a
            href="tel:+36700000000"
            className="font-bold px-4 py-3 rounded-xl text-center"
            style={{ background: "#f59e0b", color: "#1c3557" }}
          >
            📞 +36 70 000 0000
          </a>
        </div>
      )}
    </nav>
  );
}
