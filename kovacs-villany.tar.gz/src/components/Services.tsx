const services = [
  {
    icon: "🔌",
    title: "Általános Villanyszerelés",
    description:
      "Lakás- és irodai villanyszerelési munkák, hibaelhárítás, biztosítéktábla csere és korszerűsítés. Gyors reagálás, tartós megoldások.",
    items: ["Kapcsolók és aljzatok", "Biztosítéktábla csere", "Hibaelhárítás", "Világítástervezés"],
  },
  {
    icon: "🏗️",
    title: "Teljes Átvezetékezés",
    description:
      "Régi épületek elavult villamos hálózatának teljes felújítása EU-szabványok szerint. Biztonságos, modern rendszerek az Ön otthonában.",
    items: ["Teljes kábelcsere", "Korszerű védőeszközök", "Hatósági szabványok", "Műszaki dokumentáció"],
  },
  {
    icon: "☀️",
    title: "Napelem Telepítés",
    description:
      "Otthoni és kis kereskedelmi napelemes rendszerek tervezése és kivitelezése. Csökkentse villanyszámláját, fektessen be a jövőbe.",
    items: ["Rendszertervezés", "Kivitelezés és üzembe helyezés", "Hálózati csatlakozás", "Szerviz és karbantartás"],
  },
];

export default function Services() {
  return (
    <section id="szolgaltatasok" className="py-24 px-6" style={{ background: "#f8fafc" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-sm font-semibold tracking-widest uppercase mb-3" style={{ color: "#f59e0b" }}>
            Szolgáltatások
          </p>
          <h2 className="text-4xl font-bold mb-4" style={{ color: "#1c3557" }}>
            Minden villamos munkára megoldás
          </h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: "#64748b" }}>
            Kisebb javítástól a teljes rendszer felújításig — tapasztalt csapatunk mindent vállal.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((s) => (
            <div
              key={s.title}
              className="rounded-2xl p-8 flex flex-col gap-5 transition-all duration-300 hover:-translate-y-1"
              style={{ background: "#fff", border: "1px solid #e2e8f0", boxShadow: "0 2px 20px rgba(28,53,87,0.06)" }}
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl"
                style={{ background: "rgba(245,158,11,0.12)" }}
              >
                {s.icon}
              </div>
              <div>
                <h3 className="text-xl font-bold mb-3" style={{ color: "#1c3557" }}>
                  {s.title}
                </h3>
                <p className="text-sm leading-relaxed mb-4" style={{ color: "#64748b" }}>
                  {s.description}
                </p>
                <ul className="flex flex-col gap-2">
                  {s.items.map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm" style={{ color: "#475569" }}>
                      <span style={{ color: "#f59e0b" }}>✓</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
