const testimonials = [
  {
    name: "Nagy Eszter",
    location: "Szeged, Újszeged",
    service: "Biztosítéktábla csere",
    text: "Péter másnap kiszállt, gyorsan megdiagnosztizálta a problémát és még aznap megoldotta. Tisztán dolgozott, mindent elmagyarázott. Azóta is ővele csináljuk a villamos munkákat.",
    stars: 5,
  },
  {
    name: "Horváth Gábor",
    location: "Hódmezővásárhely",
    service: "Napelem telepítés",
    text: "Tavaly telepítették a 6 paneles rendszert. Pontosan kiszámolták az igényeinket, határidőre végeztek, és azóta kb. felére csökkent a villanyszámlánk. Nagyon profin csinálták.",
    stars: 5,
  },
  {
    name: "Szilágyi Réka",
    location: "Szeged, Rókus",
    service: "Teljes átvezetékezés",
    text: "1960-as évekbeli ház teljes villamos felújítása — ez nem kis feladat. Alapos felmérés, tiszta kivitelezés, határidőre kész. Az árak is becsületesek. Mindenképpen ajánlom.",
    stars: 5,
  },
];

export default function Testimonials() {
  return (
    <section id="velemenyeik" className="py-24 px-6" style={{ background: "#f8fafc" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-sm font-semibold tracking-widest uppercase mb-3" style={{ color: "#f59e0b" }}>
            Vélemények
          </p>
          <h2 className="text-4xl font-bold" style={{ color: "#1c3557" }}>
            Amit ügyfeleink mondanak
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="rounded-2xl p-8 flex flex-col gap-4"
              style={{ background: "#fff", border: "1px solid #e2e8f0", boxShadow: "0 2px 20px rgba(28,53,87,0.06)" }}
            >
              <div className="flex gap-1">
                {Array.from({ length: t.stars }).map((_, i) => (
                  <span key={i} style={{ color: "#f59e0b" }}>★</span>
                ))}
              </div>
              <p className="text-sm leading-relaxed flex-1" style={{ color: "#475569" }}>
                &ldquo;{t.text}&rdquo;
              </p>
              <div className="pt-4" style={{ borderTop: "1px solid #e2e8f0" }}>
                <div className="font-semibold text-sm" style={{ color: "#1c3557" }}>
                  {t.name}
                </div>
                <div className="text-xs" style={{ color: "#94a3b8" }}>
                  {t.location} · {t.service}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
