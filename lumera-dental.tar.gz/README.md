# Lumera — Dental Atelier

A high-end, design-led one-page site for a fictional boutique dental practice. Built as a
static Next.js export.

## Signature feature

A **scroll-driven rotating 3D treatment room**, built entirely in CSS 3D transforms (no images,
no 3D libraries). As you scroll through the `#studio` section, the camera orbits a furnished
dental suite — floor, walls, window, cabinetry and a stylised treatment chair with an overhead
operatory lamp. Captions cross-fade through "Arrival → Care → After".

## Aesthetic

Quiet-luxury: ivory + deep emerald + gold, Cormorant Garamond display serif over Jost, generous
whitespace, hairline gold rules. Deliberately distinct from a typical clinical dental site.

All contact details (phone, address, email, names) are fictional.

## Tech

- Next.js 16 (App Router, `output: "export"`)
- React 19 · Tailwind CSS v4
- Pure CSS 3D for the rotating room (`src/components/RotatingRoom.tsx`)

## Development

```bash
npm install
npm run dev     # http://localhost:3000
npm run build   # static export → ./out
```

## Easy to upgrade

Every section is its own component in `src/components/`. Swap copy, add treatments, or replace the
CSS room with real photography later — nothing is locked in.
