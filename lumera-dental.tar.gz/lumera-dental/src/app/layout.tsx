import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lumera — Dental Atelier | A higher standard of dental care",
  description:
    "Lumera is a boutique dental atelier offering cosmetic dentistry, implants, orthodontics and meticulous general care in a calm, design-led studio. By appointment.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Jost:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
