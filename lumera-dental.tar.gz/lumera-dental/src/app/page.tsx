import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import RotatingRoom from "@/components/RotatingRoom";
import Treatments from "@/components/Treatments";
import Philosophy from "@/components/Philosophy";
import Testimonials from "@/components/Testimonials";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Nav />
      <Hero />
      <RotatingRoom />
      <Treatments />
      <Philosophy />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
}
