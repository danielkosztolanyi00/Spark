"use client";

const details = [
  { label: "Telephone", value: "+1 (555) 018-2200" },
  { label: "Email", value: "care@lumera-dental.com" },
  { label: "Studio", value: "8 Linden Avenue, Suite 1200" },
  { label: "Hours", value: "Mon–Fri 9–6 · By appointment" },
];

const inputStyle = {
  background: "transparent",
  borderBottom: "1px solid var(--line)",
  color: "var(--cream)",
};

export default function Contact() {
  return (
    <section id="contact" className="py-28 px-6" style={{ background: "var(--emerald)" }}>
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-20">
        {/* Left */}
        <div>
          <p className="text-xs tracking-luxe uppercase mb-6" style={{ color: "var(--gold-bright)" }}>
            Book a consultation
          </p>
          <h2 className="serif leading-tight mb-8" style={{ color: "var(--cream)", fontSize: "clamp(2.5rem, 5vw, 4rem)" }}>
            Begin with a conversation
          </h2>
          <p className="text-base leading-relaxed mb-12 max-w-md" style={{ color: "rgba(247,243,234,0.7)" }}>
            Every new patient starts with an unhurried consultation — we listen first, then plan.
            Share a few details and we’ll be in touch within one business day.
          </p>

          <div className="grid grid-cols-2 gap-8">
            {details.map((d) => (
              <div key={d.label}>
                <div className="text-xs tracking-luxe uppercase mb-2" style={{ color: "var(--gold-bright)" }}>{d.label}</div>
                <div className="text-sm" style={{ color: "var(--cream)" }}>{d.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right — form */}
        <form className="flex flex-col gap-8" onSubmit={(e) => e.preventDefault()}>
          {[
            { label: "Full name", type: "text", ph: "Your name" },
            { label: "Email or phone", type: "text", ph: "How we reach you" },
          ].map((f) => (
            <label key={f.label} className="flex flex-col gap-3">
              <span className="text-xs tracking-luxe uppercase" style={{ color: "var(--gold-bright)" }}>{f.label}</span>
              <input type={f.type} placeholder={f.ph} className="py-3 text-base outline-none" style={inputStyle} />
            </label>
          ))}

          <label className="flex flex-col gap-3">
            <span className="text-xs tracking-luxe uppercase" style={{ color: "var(--gold-bright)" }}>Interested in</span>
            <select className="py-3 text-base outline-none" style={{ ...inputStyle, color: "var(--cream)" }}>
              {["Cosmetic dentistry", "Dental implants", "Orthodontics", "General & preventive", "Not sure yet"].map((o) => (
                <option key={o} style={{ color: "#1b2a26" }}>{o}</option>
              ))}
            </select>
          </label>

          <label className="flex flex-col gap-3">
            <span className="text-xs tracking-luxe uppercase" style={{ color: "var(--gold-bright)" }}>Message (optional)</span>
            <textarea rows={3} placeholder="Anything you'd like us to know" className="py-3 text-base outline-none resize-none" style={inputStyle} />
          </label>

          <button
            type="submit"
            className="text-xs font-medium tracking-luxe uppercase px-9 py-4 mt-2 self-start transition-all hover:opacity-90"
            style={{ background: "var(--gold)", color: "var(--emerald-2)" }}
          >
            Request appointment
          </button>
        </form>
      </div>
    </section>
  );
}
