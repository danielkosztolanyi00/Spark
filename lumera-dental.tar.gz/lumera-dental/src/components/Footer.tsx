export default function Footer() {
  return (
    <footer className="py-14 px-6" style={{ background: "var(--emerald-2)" }}>
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex items-center gap-3">
          <span
            className="w-9 h-9 rounded-full flex items-center justify-center serif text-xl"
            style={{ border: "1px solid var(--gold)", color: "var(--gold)" }}
          >
            L
          </span>
          <div>
            <div className="serif text-2xl" style={{ color: "var(--cream)" }}>Lumera</div>
            <div className="text-xs tracking-luxe uppercase" style={{ color: "rgba(247,243,234,0.45)" }}>Dental Atelier</div>
          </div>
        </div>

        <div className="flex gap-8 text-xs tracking-luxe uppercase">
          <a href="#treatments" className="no-underline hover:opacity-70" style={{ color: "rgba(247,243,234,0.6)" }}>Treatments</a>
          <a href="#philosophy" className="no-underline hover:opacity-70" style={{ color: "rgba(247,243,234,0.6)" }}>Philosophy</a>
          <a href="#contact" className="no-underline hover:opacity-70" style={{ color: "rgba(247,243,234,0.6)" }}>Book</a>
        </div>

        <div className="text-xs text-center md:text-right" style={{ color: "rgba(247,243,234,0.35)" }}>
          © {new Date().getFullYear()} Lumera Dental Atelier
          <br />
          By appointment only
        </div>
      </div>
    </footer>
  );
}
