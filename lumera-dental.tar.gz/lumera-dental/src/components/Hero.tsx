export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center" style={{ background: "var(--ivory)" }}>
      {/* soft radial light */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse at 70% 30%, rgba(212,184,120,0.18) 0%, transparent 55%)" }}
      />

      <div className="max-w-6xl mx-auto px-6 py-32 relative w-full">
        <div className="max-w-3xl fade-up">
          <p className="text-xs font-medium tracking-luxe uppercase mb-8" style={{ color: "var(--gold)" }}>
            Boutique Dental Atelier
          </p>

          <h1
            className="serif leading-[1.02] mb-8"
            style={{ color: "var(--ink)", fontSize: "clamp(3rem, 8vw, 6.5rem)" }}
          >
            A higher standard
            <br />
            of dental care.
          </h1>

          <div className="hairline w-40 mb-8" />

          <p className="text-lg leading-relaxed mb-12 max-w-xl" style={{ color: "var(--ink-soft)" }}>
            Lumera is a calm, design-led studio where precision dentistry meets quiet luxury.
            From cosmetic refinement to implants and orthodontics — every visit, considered down
            to the smallest detail.
          </p>

          <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center">
            <a
              href="#contact"
              className="text-xs font-medium tracking-luxe uppercase px-9 py-4 no-underline transition-all hover:opacity-90"
              style={{ background: "var(--emerald)", color: "var(--cream)" }}
            >
              Book a consultation
            </a>
            <a
              href="#studio"
              className="text-xs font-medium tracking-luxe uppercase no-underline transition-colors hover:opacity-60 flex items-center gap-2"
              style={{ color: "var(--ink)" }}
            >
              Step inside the studio
              <span style={{ color: "var(--gold)" }}>↓</span>
            </a>
          </div>
        </div>

        <div className="mt-24 flex flex-wrap gap-x-16 gap-y-6">
          {[
            { n: "20+", l: "Years of craft" },
            { n: "12k", l: "Smiles refined" },
            { n: "5.0", l: "Average rating" },
          ].map((s) => (
            <div key={s.l}>
              <div className="serif text-4xl mb-1" style={{ color: "var(--emerald)" }}>{s.n}</div>
              <div className="text-xs tracking-luxe uppercase" style={{ color: "var(--ink-soft)" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
