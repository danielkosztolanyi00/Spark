"use client";
import { useEffect, useState } from "react";

const links = [
  { label: "The Studio", href: "#studio" },
  { label: "Treatments", href: "#treatments" },
  { label: "Philosophy", href: "#philosophy" },
  { label: "Voices", href: "#voices" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled ? "rgba(247,243,234,0.9)" : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid var(--line)" : "1px solid transparent",
      }}
    >
      <div className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
        <a href="#" className="flex items-center gap-3 no-underline">
          <span
            className="w-9 h-9 rounded-full flex items-center justify-center serif text-xl"
            style={{ border: "1px solid var(--gold)", color: "var(--gold)" }}
          >
            L
          </span>
          <span className="serif text-2xl tracking-wide" style={{ color: "var(--ink)" }}>
            Lumera
          </span>
        </a>

        <div className="hidden md:flex items-center gap-9">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-xs font-medium tracking-luxe uppercase no-underline transition-colors hover:opacity-60"
              style={{ color: "var(--ink)" }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            className="text-xs font-medium tracking-luxe uppercase px-6 py-3 no-underline transition-all"
            style={{ background: "var(--emerald)", color: "var(--cream)" }}
          >
            Book
          </a>
        </div>

        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setOpen((v) => !v)}
          aria-label="Menu"
        >
          <span className="w-6 h-px" style={{ background: "var(--ink)" }} />
          <span className="w-6 h-px" style={{ background: "var(--ink)" }} />
          <span className="w-6 h-px" style={{ background: "var(--ink)" }} />
        </button>
      </div>

      {open && (
        <div className="md:hidden px-6 pb-6 flex flex-col gap-4" style={{ background: "rgba(247,243,234,0.97)" }}>
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-xs font-medium tracking-luxe uppercase no-underline py-1"
              style={{ color: "var(--ink)" }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="text-xs font-medium tracking-luxe uppercase px-6 py-3 no-underline text-center"
            style={{ background: "var(--emerald)", color: "var(--cream)" }}
          >
            Book a consultation
          </a>
        </div>
      )}
    </nav>
  );
}
