const voices = [
  {
    text: "I used to dread the dentist. At Lumera I genuinely look forward to it — it feels like stepping into a spa, and my veneers are flawless.",
    name: "Charlotte M.",
    detail: "Cosmetic patient",
  },
  {
    text: "The implant process was explained at every step, completely painless, and the result is indistinguishable from my own teeth. Exceptional.",
    name: "James R.",
    detail: "Implant patient",
  },
  {
    text: "Calm, immaculate, and never rushed. The whole team remembers you. This is how healthcare should feel.",
    name: "Priya S.",
    detail: "General care",
  },
];

export default function Testimonials() {
  return (
    <section id="voices" className="py-28 px-6" style={{ background: "var(--ivory-2)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <p className="text-xs tracking-luxe uppercase mb-4" style={{ color: "var(--gold)" }}>
            In their words
          </p>
          <h2 className="serif text-5xl" style={{ color: "var(--ink)" }}>
            Patient voices
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {voices.map((v) => (
            <div key={v.name} className="flex flex-col">
              <div className="serif text-6xl leading-none mb-4" style={{ color: "var(--gold)" }}>“</div>
              <p className="serif text-2xl leading-snug flex-1 mb-8" style={{ color: "var(--ink)" }}>
                {v.text}
              </p>
              <div className="hairline w-12 mb-4" />
              <div className="text-sm font-medium" style={{ color: "var(--ink)" }}>{v.name}</div>
              <div className="text-xs tracking-luxe uppercase mt-1" style={{ color: "var(--ink-soft)" }}>{v.detail}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
