const treatments = [
  {
    num: "Ⅰ",
    title: "Cosmetic Dentistry",
    desc: "Veneers, whitening and smile design — refined to your features, never overdone.",
  },
  {
    num: "Ⅱ",
    title: "Dental Implants",
    desc: "Permanent, natural-feeling replacements placed with surgical precision and guided imaging.",
  },
  {
    num: "Ⅲ",
    title: "Orthodontics",
    desc: "Discreet clear aligners and modern braces for adults and teens, planned digitally.",
  },
  {
    num: "Ⅳ",
    title: "General & Preventive",
    desc: "Meticulous check-ups, hygiene and restorative care that keeps problems away for good.",
  },
];

export default function Treatments() {
  return (
    <section id="treatments" className="py-28 px-6" style={{ background: "var(--ivory)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <p className="text-xs tracking-luxe uppercase mb-4" style={{ color: "var(--gold)" }}>
            What we do
          </p>
          <h2 className="serif text-5xl" style={{ color: "var(--ink)" }}>
            Treatments, considered
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 gap-px" style={{ background: "var(--line)" }}>
          {treatments.map((t) => (
            <div
              key={t.title}
              className="p-12 transition-colors duration-500 group"
              style={{ background: "var(--ivory)" }}
            >
              <div className="serif text-4xl mb-6" style={{ color: "var(--gold)" }}>{t.num}</div>
              <h3 className="serif text-3xl mb-4" style={{ color: "var(--ink)" }}>{t.title}</h3>
              <p className="text-sm leading-relaxed max-w-sm" style={{ color: "var(--ink-soft)" }}>
                {t.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
