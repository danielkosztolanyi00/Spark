import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Treatments from "@/components/Treatments";
import Manifesto from "@/components/Manifesto";
import Testimonials from "@/components/Testimonials";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Nav />
      <Hero />
      <Marquee />
      <Treatments />
      <Manifesto />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
}
