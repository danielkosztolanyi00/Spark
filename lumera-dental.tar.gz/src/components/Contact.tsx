"use client";

export default function Contact() {
  return (
    <section id="contact" className="px-6 md:px-10 py-20">
      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-3 mb-16">
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          04 — Begin
        </span>
      </div>

      <div className="grid md:grid-cols-2 gap-16 md:gap-24">
        {/* Left */}
        <div>
          <h2
            className="display leading-[0.88] mb-10"
            style={{ fontSize: "clamp(4rem, 10vw, 9rem)", color: "var(--ink)" }}
          >
            Begin.
          </h2>
          <p className="text-sm leading-relaxed mb-12 max-w-[30ch]" style={{ color: "var(--dust)" }}>
            Every new patient starts with an unhurried consultation.
            We listen first, then plan.
          </p>

          <div className="space-y-5">
            {[
              ["Email", "care@lumera-dental.com"],
              ["Phone", "+1 (555) 018-2200"],
              ["Studio", "8 Linden Avenue, Suite 1200"],
              ["Hours", "Mon–Fri 9–6 · By appointment"],
            ].map(([label, value]) => (
              <div key={label} className="flex items-baseline gap-5">
                <span
                  className="mono text-[9px] tracking-[0.28em] uppercase w-12 flex-shrink-0"
                  style={{ color: "var(--wheat)" }}
                >
                  {label}
                </span>
                <span className="text-sm" style={{ color: "var(--ink)" }}>
                  {value}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right — form */}
        <form className="flex flex-col gap-9" onSubmit={(e) => e.preventDefault()}>
          {[
            { label: "Name", type: "text", ph: "Your full name" },
            { label: "Email or phone", type: "text", ph: "How we reach you" },
          ].map((f) => (
            <label key={f.label} className="flex flex-col gap-2">
              <span className="mono text-[9px] tracking-[0.28em] uppercase" style={{ color: "var(--wheat)" }}>
                {f.label}
              </span>
              <input
                type={f.type}
                placeholder={f.ph}
                className="bg-transparent py-3 text-sm outline-none"
                style={{ borderBottom: "1px solid var(--line)", color: "var(--ink)" }}
              />
            </label>
          ))}

          <label className="flex flex-col gap-2">
            <span className="mono text-[9px] tracking-[0.28em] uppercase" style={{ color: "var(--wheat)" }}>
              Interested in
            </span>
            <select
              className="bg-transparent py-3 text-sm outline-none"
              style={{ borderBottom: "1px solid var(--line)", color: "var(--ink)" }}
            >
              {["Cosmetic dentistry", "Dental implants", "Orthodontics", "General care", "Not sure yet"].map((o) => (
                <option key={o} style={{ background: "var(--paper)" }}>
                  {o}
                </option>
              ))}
            </select>
          </label>

          <label className="flex flex-col gap-2">
            <span className="mono text-[9px] tracking-[0.28em] uppercase" style={{ color: "var(--wheat)" }}>
              Message
            </span>
            <textarea
              rows={3}
              placeholder="Anything you'd like us to know"
              className="bg-transparent py-3 text-sm outline-none resize-none"
              style={{ borderBottom: "1px solid var(--line)", color: "var(--ink)" }}
            />
          </label>

          <div className="pt-2">
            <button
              type="submit"
              className="flex items-center gap-5 group"
              style={{ color: "var(--ink)" }}
            >
              <span className="text-xs tracking-[0.22em] uppercase">Send request</span>
              <span
                className="h-px block transition-all duration-500 group-hover:w-16"
                style={{ background: "var(--wheat)", width: "2rem" }}
              />
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}
