export default function Footer() {
  return (
    <footer
      className="px-6 md:px-10 py-8"
      style={{ borderTop: "1px solid var(--line)" }}
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          Lumera Dental Atelier
        </span>
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          © {new Date().getFullYear()} · By Appointment Only
        </span>
        <div className="flex gap-8">
          {[
            ["Treatments", "#treatments"],
            ["Voices", "#voices"],
            ["Book", "#contact"],
          ].map(([label, href]) => (
            <a
              key={href}
              href={href}
              className="mono text-[10px] tracking-[0.22em] uppercase no-underline hover:opacity-50 transition-opacity"
              style={{ color: "var(--dust)" }}
            >
              {label}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}
