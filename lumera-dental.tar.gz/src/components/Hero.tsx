export default function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col px-6 md:px-10 pt-24 pb-12 overflow-hidden">
      {/* oversized faint tooth watermark */}
      <svg
        viewBox="0 0 100 120"
        aria-hidden="true"
        className="absolute pointer-events-none select-none"
        style={{
          right: "-6vw",
          top: "50%",
          transform: "translateY(-50%) rotate(-8deg)",
          height: "82vh",
          width: "auto",
          opacity: 0.1,
          zIndex: 0,
        }}
      >
        <path
          d="M28,22 Q32,10 42,14 Q50,6 58,14 Q68,10 72,22 C76,34 70,42 68,52 C66,66 64,82 60,104 L56,96 C53,86 47,86 44,96 L40,104 C36,82 34,66 32,52 C30,42 24,34 28,22 Z"
          fill="none"
          stroke="var(--wheat)"
          strokeWidth="0.8"
          strokeLinejoin="round"
        />
        {/* inner contour line for depth */}
        <path
          d="M40,30 Q50,24 60,30 C63,40 60,48 58,58 C56,72 54,84 51,96"
          fill="none"
          stroke="var(--wheat)"
          strokeWidth="0.5"
          strokeLinecap="round"
          opacity="0.7"
        />
      </svg>

      {/* top thin rule + meta labels */}
      <div className="rule" />
      <div className="flex items-center justify-between py-4">
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          Dental Atelier — Est. 2003
        </span>
        <span className="mono text-[10px] tracking-[0.28em] uppercase hidden sm:block" style={{ color: "var(--dust)" }}>
          London · By Appointment
        </span>
      </div>
      <div className="rule" />

      {/* main oversized oblique headline */}
      <div className="flex-1 flex items-center py-8 relative" style={{ zIndex: 10 }}>
        <h1
          className="display leading-[0.88]"
          style={{
            fontSize: "clamp(4.5rem, 16vw, 15rem)",
            color: "var(--ink)",
            letterSpacing: "-0.025em",
          }}
        >
          Light,
          <br />
          in every
          <br />
          detail.
        </h1>
      </div>

      {/* bottom: description left, stats right */}
      <div>
        <div className="rule mb-8" />
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-8">
          <div>
            <p className="text-sm leading-relaxed max-w-[30ch]" style={{ color: "var(--dust)" }}>
              Lumera is a calm, considered studio
              where precision dentistry meets
              quiet, intentional design.
            </p>
            <a
              href="#treatments"
              className="inline-flex items-center gap-4 mt-6 no-underline group"
              style={{ color: "var(--ink)" }}
            >
              <span className="text-xs tracking-[0.2em] uppercase">Discover</span>
              <span
                className="h-px transition-all duration-500 group-hover:w-16"
                style={{ background: "var(--ink)", display: "block", width: "2rem" }}
              />
            </a>
          </div>

          <div className="flex gap-10 sm:gap-12">
            {[
              ["20+", "Years"],
              ["12k", "Patients"],
              ["5.0", "Rating"],
            ].map(([n, l]) => (
              <div key={l}>
                <div
                  className="display"
                  style={{ fontSize: "clamp(1.5rem, 2.5vw, 2.5rem)", color: "var(--ink)", lineHeight: 1 }}
                >
                  {n}
                </div>
                <div className="mono text-[9px] tracking-[0.25em] uppercase mt-2" style={{ color: "var(--dust)" }}>
                  {l}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
