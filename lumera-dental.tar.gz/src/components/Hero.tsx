export default function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col px-6 md:px-10 pt-24 pb-12 overflow-hidden">
      {/* top thin rule + meta labels */}
      <div className="rule" />
      <div className="flex items-center justify-between py-4">
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          Dental Atelier — Est. 2003
        </span>
        <span className="mono text-[10px] tracking-[0.28em] uppercase hidden sm:block" style={{ color: "var(--dust)" }}>
          London · By Appointment
        </span>
      </div>
      <div className="rule" />

      {/* main oversized oblique headline */}
      <div className="flex-1 flex items-center py-8">
        <h1
          className="display leading-[0.88]"
          style={{
            fontSize: "clamp(4.5rem, 16vw, 15rem)",
            color: "var(--ink)",
            letterSpacing: "-0.025em",
          }}
        >
          Light,
          <br />
          in every
          <br />
          detail.
        </h1>
      </div>

      {/* bottom: description left, stats right */}
      <div>
        <div className="rule mb-8" />
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-8">
          <div>
            <p className="text-sm leading-relaxed max-w-[30ch]" style={{ color: "var(--dust)" }}>
              Lumera is a calm, considered studio
              where precision dentistry meets
              quiet, intentional design.
            </p>
            <a
              href="#treatments"
              className="inline-flex items-center gap-4 mt-6 no-underline group"
              style={{ color: "var(--ink)" }}
            >
              <span className="text-xs tracking-[0.2em] uppercase">Discover</span>
              <span
                className="h-px transition-all duration-500 group-hover:w-16"
                style={{ background: "var(--ink)", display: "block", width: "2rem" }}
              />
            </a>
          </div>

          <div className="flex gap-10 sm:gap-12">
            {[
              ["20+", "Years"],
              ["12k", "Patients"],
              ["5.0", "Rating"],
            ].map(([n, l]) => (
              <div key={l}>
                <div
                  className="display"
                  style={{ fontSize: "clamp(1.5rem, 2.5vw, 2.5rem)", color: "var(--ink)", lineHeight: 1 }}
                >
                  {n}
                </div>
                <div className="mono text-[9px] tracking-[0.25em] uppercase mt-2" style={{ color: "var(--dust)" }}>
                  {l}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
