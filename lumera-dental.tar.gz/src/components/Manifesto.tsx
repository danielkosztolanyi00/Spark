"use client";
import { useEffect, useRef, useState } from "react";

const sentence =
  "We believe dentistry should feel calm — unhurried — entirely human — where the science is exacting — and the experience is gentle.";

export default function Manifesto() {
  const words = sentence.split(" ");
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true);
      },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="manifesto" className="px-6 md:px-10 py-24">
      <div className="rule mb-12" />

      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-3 mb-16">
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          02 — Philosophy
        </span>
      </div>

      <div ref={ref} className="max-w-5xl">
        <p
          className="display leading-[1.2]"
          style={{ fontSize: "clamp(1.8rem, 3.2vw, 3.2rem)", color: "var(--ink)" }}
        >
          {words.map((word, i) => (
            <span
              key={i}
              style={{
                display: "inline-block",
                marginRight: "0.32em",
                opacity: visible ? 1 : 0,
                transform: visible ? "none" : "translateY(12px)",
                transition: `opacity 0.55s ease ${i * 0.038}s, transform 0.55s ease ${i * 0.038}s`,
              }}
            >
              {word}
            </span>
          ))}
        </p>
      </div>

      <div className="flex items-center gap-5 mt-16">
        <div className="h-px w-10" style={{ background: "var(--wheat)" }} />
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          Dr. Eleanor Vance — Clinical Director
        </span>
      </div>

      <div className="rule mt-16" />
    </section>
  );
}
