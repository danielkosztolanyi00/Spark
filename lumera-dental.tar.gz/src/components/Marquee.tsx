const items = [
  "Cosmetic Dentistry",
  "Dental Implants",
  "Orthodontics",
  "Ceramic Veneers",
  "Preventive Care",
  "Smile Design",
  "Same-Day Ceramics",
  "Digital Scanning",
];

export default function Marquee() {
  const track = [...items, ...items];

  return (
    <div
      className="overflow-hidden"
      style={{ borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)" }}
    >
      <div
        style={{
          display: "flex",
          width: "max-content",
          animation: "marquee 36s linear infinite",
        }}
      >
        {track.map((item, i) => (
          <span
            key={i}
            style={{
              display: "inline-flex",
              alignItems: "center",
              padding: "1rem 0",
            }}
          >
            <span
              className="display"
              style={{ fontSize: "0.95rem", color: "var(--ink)", whiteSpace: "nowrap", padding: "0 2rem" }}
            >
              {item}
            </span>
            <span className="mono" style={{ fontSize: "0.6rem", color: "var(--wheat)" }}>
              ∙
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}
