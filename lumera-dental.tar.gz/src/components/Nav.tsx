"use client";
import { useEffect, useState } from "react";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", h, { passive: true });
    return () => window.removeEventListener("scroll", h);
  }, []);

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-700"
      style={{
        borderBottom: scrolled ? "1px solid var(--line)" : "1px solid transparent",
        background: scrolled ? "rgba(244,241,235,0.94)" : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
      }}
    >
      <div className="px-6 md:px-10 py-5 flex items-center justify-between">
        <a href="#" className="mono text-xs tracking-[0.3em] uppercase no-underline" style={{ color: "var(--ink)" }}>
          Lumera
        </a>

        <div className="hidden md:flex items-center gap-10">
          {[
            ["01", "Treatments", "#treatments"],
            ["02", "Voices", "#voices"],
            ["03", "Book", "#contact"],
          ].map(([num, label, href]) => (
            <a
              key={href}
              href={href}
              className="flex items-center gap-2 no-underline opacity-100 hover:opacity-50 transition-opacity duration-300"
              style={{ color: "var(--ink)" }}
            >
              <span className="mono text-[9px]" style={{ color: "var(--dust)" }}>{num}</span>
              <span className="text-[11px] tracking-wider uppercase">{label}</span>
            </a>
          ))}
        </div>

        <button
          className="md:hidden flex flex-col gap-[5px] p-1"
          onClick={() => setOpen((v) => !v)}
          aria-label="Menu"
        >
          <span className="w-5 h-px block transition-all duration-300" style={{ background: "var(--ink)", transform: open ? "rotate(45deg) translateY(4px)" : "none" }} />
          <span className="w-5 h-px block transition-all duration-300" style={{ background: "var(--ink)", transform: open ? "rotate(-45deg) translateY(-4px)" : "none" }} />
        </button>
      </div>

      {open && (
        <div className="md:hidden px-6 pb-10 flex flex-col gap-7" style={{ background: "rgba(244,241,235,0.97)" }}>
          {[
            ["Treatments", "#treatments"],
            ["Voices", "#voices"],
            ["Book a Consultation", "#contact"],
          ].map(([label, href]) => (
            <a
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              className="mono text-xs tracking-[0.25em] uppercase no-underline"
              style={{ color: "var(--ink)" }}
            >
              {label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}
