export default function Philosophy() {
  return (
    <section id="philosophy" className="py-28 px-6" style={{ background: "var(--emerald)" }}>
      <div className="max-w-5xl mx-auto text-center">
        <p className="text-xs tracking-luxe uppercase mb-8" style={{ color: "var(--gold-bright)" }}>
          Our philosophy
        </p>
        <blockquote
          className="serif leading-tight mb-10"
          style={{ color: "var(--cream)", fontSize: "clamp(1.8rem, 4vw, 3rem)" }}
        >
          “We believe dentistry should feel calm, unhurried and entirely human —
          where the science is exacting, and the experience is gentle.”
        </blockquote>
        <div className="hairline w-32 mx-auto mb-8" />
        <p className="text-sm tracking-luxe uppercase" style={{ color: "rgba(247,243,234,0.6)" }}>
          Dr. Eleanor Vance — Clinical Director
        </p>

        <div className="grid sm:grid-cols-3 gap-12 mt-24 text-left">
          {[
            { t: "Time, not rush", d: "Generous appointment windows so nothing is hurried — including your questions." },
            { t: "Quiet technology", d: "Digital scanning and same-day ceramics mean fewer visits and no messy impressions." },
            { t: "One team", d: "You see the same familiar faces every visit — continuity is part of the care." },
          ].map((c) => (
            <div key={c.t}>
              <div className="hairline w-10 mb-5" />
              <h3 className="serif text-2xl mb-3" style={{ color: "var(--cream)" }}>{c.t}</h3>
              <p className="text-sm leading-relaxed" style={{ color: "rgba(247,243,234,0.65)" }}>{c.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
