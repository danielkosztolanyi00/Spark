"use client";
import { useEffect, useRef, useState, CSSProperties } from "react";

// Room dimensions (px)
const W = 440; // width
const H = 300; // height
const D = 440; // depth
const HW = W / 2;
const HH = H / 2;
const HD = D / 2;

function face(w: number, h: number, transform: string, extra: CSSProperties = {}): CSSProperties {
  return {
    position: "absolute",
    left: "50%",
    top: "50%",
    width: `${w}px`,
    height: `${h}px`,
    marginLeft: `${-w / 2}px`,
    marginTop: `${-h / 2}px`,
    transform,
    backfaceVisibility: "visible",
    ...extra,
  };
}

const captions = [
  { eyebrow: "01 — Arrival", title: "Reception & lounge" },
  { eyebrow: "02 — Care", title: "The treatment suite" },
  { eyebrow: "03 — After", title: "Consultation & recovery" },
];

export default function RotatingRoom() {
  const ref = useRef<HTMLDivElement>(null);
  const [p, setP] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const el = ref.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const total = el.offsetHeight - window.innerHeight;
      const scrolled = Math.min(Math.max(-rect.top, 0), total);
      setP(total > 0 ? scrolled / total : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const rotY = 24 - p * 150;
  const rotX = -16 + p * 9;
  const cap = captions[Math.min(captions.length - 1, Math.floor(p * 3))];

  // wall surface base
  const wall: CSSProperties = { background: "linear-gradient(180deg, #14463a 0%, #0d3128 100%)" };
  const wallInner: CSSProperties = { background: "linear-gradient(180deg, #15493c 0%, #0e352b 100%)" };

  return (
    <section id="studio" ref={ref} style={{ height: "360vh", position: "relative", background: "var(--emerald)" }}>
      <div className="sticky top-0 h-screen w-full overflow-hidden flex items-center justify-center">
        {/* ambient light */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse at 50% 40%, rgba(212,184,120,0.14) 0%, transparent 60%)" }}
        />

        {/* overlay copy */}
        <div className="absolute z-20 left-6 sm:left-12 top-1/2 -translate-y-1/2 max-w-xs pointer-events-none">
          <p className="text-xs tracking-luxe uppercase mb-3" style={{ color: "var(--gold-bright)" }}>
            {cap.eyebrow}
          </p>
          <h2 className="serif text-4xl sm:text-5xl leading-tight mb-4" style={{ color: "var(--cream)" }}>
            {cap.title}
          </h2>
          <div className="hairline w-24 mb-4" />
          <p className="text-sm leading-relaxed" style={{ color: "rgba(247,243,234,0.7)" }}>
            Scroll to move through the studio — every space designed to feel less like a clinic,
            more like a retreat.
          </p>
        </div>

        {/* 3D scene */}
        <div
          className="scale-[0.5] sm:scale-[0.7] lg:scale-90"
          style={{ perspective: "1500px", perspectiveOrigin: "50% 45%" }}
        >
          <div
            style={{
              width: `${W}px`,
              height: `${H}px`,
              position: "relative",
              transformStyle: "preserve-3d",
              transform: `translateZ(-40px) rotateX(${rotX}deg) rotateY(${rotY}deg)`,
              transition: "transform 0.08s linear",
            }}
          >
            {/* FLOOR */}
            <div style={face(W, D, `rotateX(-90deg) translateZ(${HH}px)`, {
              background: "linear-gradient(135deg, #efe9db 0%, #e2dac6 100%)",
              boxShadow: "inset 0 0 80px rgba(14,59,49,0.15)",
            })}>
              {/* marble seams */}
              <div className="absolute inset-0" style={{
                backgroundImage:
                  "linear-gradient(rgba(14,59,49,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(14,59,49,0.06) 1px, transparent 1px)",
                backgroundSize: "110px 110px",
              }} />
              {/* gold rug ring */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
                style={{ width: 230, height: 230, border: "2px solid rgba(194,162,95,0.5)" }} />
            </div>

            {/* CEILING */}
            <div style={face(W, D, `rotateX(90deg) translateZ(${HH}px)`, {
              background: "linear-gradient(135deg, #0d3128 0%, #0a2820 100%)",
            })}>
              {/* recessed light */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
                style={{ width: 120, height: 120, background: "radial-gradient(circle, rgba(212,184,120,0.6) 0%, transparent 70%)" }} />
            </div>

            {/* BACK WALL */}
            <div style={face(W, H, `rotateY(180deg) translateZ(${HD}px)`, wall)}>
              <div className="absolute inset-0 flex items-center justify-center gap-6">
                {/* paneling */}
                <div className="absolute inset-0" style={{
                  backgroundImage: "repeating-linear-gradient(90deg, transparent 0 70px, rgba(255,255,255,0.04) 70px 72px)",
                }} />
                {/* gold wainscot line */}
                <div className="absolute left-0 right-0" style={{ bottom: 70, height: 1, background: "rgba(212,184,120,0.5)" }} />
                {/* framed piece */}
                <div className="relative" style={{ width: 120, height: 150, border: "3px solid var(--gold)", background: "rgba(247,243,234,0.06)" }}>
                  <div className="absolute inset-3 serif flex items-center justify-center text-center text-xs" style={{ color: "rgba(247,243,234,0.5)" }}>
                    Lumera
                  </div>
                </div>
              </div>
            </div>

            {/* LEFT WALL — window */}
            <div style={face(D, H, `rotateY(-90deg) translateZ(${HW}px)`, wallInner)}>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="grid grid-cols-2 gap-2" style={{ width: 200, height: 160 }}>
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} style={{ background: "linear-gradient(160deg, rgba(212,184,120,0.35), rgba(247,243,234,0.08))", border: "2px solid rgba(212,184,120,0.4)" }} />
                  ))}
                </div>
              </div>
            </div>

            {/* RIGHT WALL — cabinet */}
            <div style={face(D, H, `rotateY(90deg) translateZ(${HW}px)`, wallInner)}>
              <div className="absolute inset-0 flex items-end justify-center pb-8">
                <div style={{ width: 220, height: 70, background: "rgba(247,243,234,0.1)", borderTop: "2px solid var(--gold)" }} />
              </div>
              <div className="absolute left-1/2 -translate-x-1/2" style={{ top: 70, width: 220, height: 1, background: "rgba(212,184,120,0.4)" }} />
            </div>

            {/* ===== DENTAL CHAIR (center) ===== */}
            <div style={{ position: "absolute", left: "50%", top: "50%", transformStyle: "preserve-3d", transform: "translate(-50%,-50%)" }}>
              {/* base plate on floor */}
              <div style={face(140, 140, `rotateX(-90deg) translateZ(-${HH - 4}px)`, {
                background: "radial-gradient(circle, #0e3b31 0%, #0a2c25 70%)",
                borderRadius: "50%",
              })} />
              {/* pedestal — crossed panels for solidity */}
              <div style={face(46, 110, `translateY(95px) translateZ(0px)`, { background: "linear-gradient(180deg,#13463a,#0d2f27)", borderRadius: 8 })} />
              <div style={face(46, 110, `translateY(95px) rotateY(90deg)`, { background: "linear-gradient(180deg,#0f3a2f,#0b2a22)", borderRadius: 8 })} />
              {/* seat (reclined slab) */}
              <div style={face(120, 170, `translateY(55px) rotateX(74deg)`, {
                background: "linear-gradient(180deg,#f7f3ea,#e6dec9)",
                borderRadius: 22,
                boxShadow: "0 0 0 3px rgba(194,162,95,0.5)",
              })} />
              {/* backrest */}
              <div style={face(116, 150, `translateY(-2px) translateZ(-72px) rotateX(20deg)`, {
                background: "linear-gradient(180deg,#fdfbf5,#ece4d0)",
                borderRadius: 22,
                boxShadow: "0 0 0 3px rgba(194,162,95,0.5)",
              })} />
              {/* headrest */}
              <div style={face(70, 46, `translateY(-78px) translateZ(-92px) rotateX(20deg)`, {
                background: "#f7f3ea",
                borderRadius: 14,
                boxShadow: "0 0 0 3px rgba(194,162,95,0.5)",
              })} />
              {/* overhead lamp arm */}
              <div style={face(8, 150, `translateY(-110px) translateZ(40px) rotateX(35deg)`, { background: "#0d3128", borderRadius: 6 })} />
              {/* lamp head */}
              <div style={face(110, 110, `translateY(-150px) translateZ(70px) rotateX(60deg)`, {
                background: "radial-gradient(circle, #fff8e6 0%, #e9d49a 45%, #0e3b31 46%, #0a2c25 100%)",
                borderRadius: "50%",
                boxShadow: "0 0 60px rgba(212,184,120,0.6)",
                animation: "lamp-glow 3s ease-in-out infinite",
              })} />
            </div>
          </div>
        </div>

        {/* progress bar */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-40 h-px" style={{ background: "rgba(247,243,234,0.2)" }}>
          <div className="h-full" style={{ width: `${p * 100}%`, background: "var(--gold-bright)" }} />
        </div>
      </div>
    </section>
  );
}
