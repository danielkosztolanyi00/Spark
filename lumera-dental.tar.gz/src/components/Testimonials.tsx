"use client";
import { useState } from "react";

const voices = [
  {
    text: "I used to dread the dentist. At Lumera I genuinely look forward to it — it feels like stepping into a private spa, and my veneers are flawless.",
    name: "Charlotte M.",
    detail: "Cosmetic patient",
  },
  {
    text: "The implant process was explained at every step, completely painless, and the result is indistinguishable from my own teeth. Exceptional.",
    name: "James R.",
    detail: "Implant patient",
  },
  {
    text: "Calm, immaculate, and never rushed. The whole team remembers you. This is how healthcare should feel.",
    name: "Priya S.",
    detail: "General care",
  },
];

export default function Testimonials() {
  const [idx, setIdx] = useState(0);
  const v = voices[idx];

  return (
    <section id="voices" className="px-6 md:px-10 py-24">
      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-3 mb-14">
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          03 — In their words
        </span>
      </div>

      <div className="max-w-4xl">
        <div
          key={idx}
          className="display leading-[1.25] mb-10"
          style={{
            fontSize: "clamp(1.5rem, 2.8vw, 2.8rem)",
            color: "var(--ink)",
            animation: "fade-up 0.5s ease both",
          }}
        >
          "{v.text}"
        </div>

        <div className="flex items-center gap-5">
          <div className="h-px w-8" style={{ background: "var(--wheat)" }} />
          <div>
            <div className="text-sm" style={{ color: "var(--ink)", fontWeight: 400 }}>
              {v.name}
            </div>
            <div className="mono text-[9px] tracking-[0.22em] uppercase mt-1" style={{ color: "var(--dust)" }}>
              {v.detail}
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-6 mt-12">
        <button
          onClick={() => setIdx((i) => (i - 1 + voices.length) % voices.length)}
          className="mono text-xs flex items-center gap-2 hover:opacity-50 transition-opacity"
          style={{ color: "var(--ink)" }}
        >
          ← prev
        </button>
        <span className="mono text-[9px]" style={{ color: "var(--dust)" }}>
          {String(idx + 1).padStart(2, "0")} / {String(voices.length).padStart(2, "0")}
        </span>
        <button
          onClick={() => setIdx((i) => (i + 1) % voices.length)}
          className="mono text-xs flex items-center gap-2 hover:opacity-50 transition-opacity"
          style={{ color: "var(--ink)" }}
        >
          next →
        </button>
      </div>

      <div className="rule mt-16" />
    </section>
  );
}
