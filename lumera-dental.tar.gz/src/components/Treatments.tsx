"use client";
import { useState } from "react";

const items = [
  {
    n: "01",
    title: "Cosmetic Dentistry",
    sub: "Veneers · Whitening · Smile Design",
    desc: "Refined to your features, never overdone. Digital mockups before anything begins.",
  },
  {
    n: "02",
    title: "Dental Implants",
    sub: "Single · Multiple · Full Arch",
    desc: "Permanent, natural-feeling replacements placed with guided surgical imaging.",
  },
  {
    n: "03",
    title: "Orthodontics",
    sub: "Clear Aligners · Modern Braces",
    desc: "Discreet treatment for adults and teens. Planned digitally from first scan to finish.",
  },
  {
    n: "04",
    title: "General & Preventive",
    sub: "Hygiene · Restorative · Check-ups",
    desc: "Meticulous, unhurried care that keeps problems away for good.",
  },
];

export default function Treatments() {
  const [hovered, setHovered] = useState<string | null>(null);

  return (
    <section id="treatments" className="px-6 md:px-10 py-20">
      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-3 mb-10">
        <span className="mono text-[10px] tracking-[0.28em] uppercase" style={{ color: "var(--dust)" }}>
          01 — What we offer
        </span>
        <span className="display text-lg" style={{ color: "var(--dust)" }}>
          Treatments, considered
        </span>
      </div>

      <div>
        {items.map((item) => (
          <div
            key={item.n}
            onMouseEnter={() => setHovered(item.n)}
            onMouseLeave={() => setHovered(null)}
            className="relative"
            style={{ borderTop: "1px solid var(--line)" }}
          >
            {/* hover wash */}
            <div
              className="absolute inset-0 pointer-events-none transition-opacity duration-500"
              style={{
                background: "linear-gradient(90deg, transparent 40%, rgba(196,164,106,0.06))",
                opacity: hovered === item.n ? 1 : 0,
              }}
            />

            <div className="flex items-start gap-5 md:gap-10 py-7 relative">
              <span className="mono text-xs pt-1 w-8 flex-shrink-0" style={{ color: "var(--dust)" }}>
                {item.n}
              </span>

              <div className="flex flex-col md:flex-row md:items-baseline gap-3 md:gap-12 flex-1">
                <div className="flex-1">
                  <div
                    className="display"
                    style={{
                      fontSize: "clamp(1.5rem, 2.8vw, 2.6rem)",
                      color: "var(--ink)",
                      lineHeight: 1.1,
                      transition: "letter-spacing 0.4s ease",
                      letterSpacing: hovered === item.n ? "-0.01em" : "-0.025em",
                    }}
                  >
                    {item.title}
                  </div>
                  <div
                    className="mono text-[9px] tracking-[0.22em] uppercase mt-2"
                    style={{ color: "var(--wheat)" }}
                  >
                    {item.sub}
                  </div>
                </div>

                <p
                  className="text-sm leading-relaxed md:text-right max-w-xs"
                  style={{ color: "var(--dust)" }}
                >
                  {item.desc}
                </p>
              </div>
            </div>
          </div>
        ))}
        <div className="rule" />
      </div>
    </section>
  );
}
